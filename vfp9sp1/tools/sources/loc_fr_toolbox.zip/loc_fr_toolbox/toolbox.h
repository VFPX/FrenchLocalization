#define TOOLBOX_LOC						"Toolbox"


* used by ToolBox.ShowType field
#define SHOWTYPE_CATEGORY	'C'
#define SHOWTYPE_TOOL		'T'
#define SHOWTYPE_FAVORITES	'F'
#define SHOWTYPE_FILTER		'S'
#define SHOWTYPE_FILTERITEM	'I'

* add-ins that shows on the menu
#define SHOWTYPE_ADDIN		'A'
#define SHOWTYPE_ADDINMENU	'M'  && menu option only

* -- Default classes and class library

* this is the vcx that should be found in HOME() + "Toolbox"
#define DEFAULT_CLASSLIB		"_toolbox.vcx"

* if we don't find the above, we maintain a copy internal to the APP
#define INTERNAL_CLASSLIB		"_toolboxdefault.vcx"

#define FILTERCLASS_NAME		"_filter"
#define FILTERCLASS_ITEM		"_filteritem"

#define CATEGORYCLASS_GENERAL	"_generalcategory"
#define CATEGORYCLASS_FAVORITES	"_favoritescategory"

#define ITEMCLASS_ROOT			"_root"
#define ITEMCLASS_TOOL			"_tool"
#define ITEMCLASS_CLASS			"_classtool"
#define ITEMCLASS_ACTIVEX		"_activextool"
#define ITEMCLASS_TEXTSCRAP		"_textscraptool"

#define SCROLLSPEED_DEFAULT		30
#define FONT_DEFAULT			"Tahoma,8,N"

#define DRAGSTATE_START		1
#define DRAGSTATE_COMPLETE	2

#define NEWLINE				CHR(13) + CHR(10)

#define tvwFirst	0
#define tvwLast		1
#define tvwNext		2
#define tvwPrevious	3
#define tvwChild	4


#define WIN_PJX_DESIGN_LOC			"OUTIL CR�ATION PROJET -"
#define WIN_SCX_DESIGN_LOC			"OUTIL CR�ATION FORMES -"
#define WIN_VCX_DESIGN_LOC			"OUTIL CR�ATION CLASSES -"
#define WIN_FRX_DESIGN_LOC			"OUTIL CR�ATION RAPPORT -"
#define WIN_MNX1_DESIGN_LOC			"OUTIL CR�ATION MENU -"
#define WIN_MNX2_DESIGN_LOC			"OUTIL CR�ATION RACCOURCIS -"
#define WIN_DBC_DESIGN_LOC			"OUTIL CR�ATION DATABASE -"


#define VFP_OPTIONS_KEY				"Software\Microsoft\VisualFoxPro\"
#define VFP_OPTIONS_KEY2			"\Options\OLEList"
#define HKEY_CLASSES_ROOT			-2147483648  && BITSET(0,31)
#define HKEY_CURRENT_USER			-2147483647  && BITSET(0,31)+1
#define CLSID_KEY					"CLSID"
#define PROGID_KEY					"\ProgID"
#define CONTROL_KEY					"Control"
#define SERVER_KEY					"Programmable"
#define SHELL_KEY					"\Shell\"
#define INPROC_KEY					"InProcServer32"
#define LOCALSVR_KEY				"LocalServer32"

#define INTELLIDROP_KEY				"Software\Microsoft\VisualFoxPro\" + _VFP.Version + "\Options\IntelliDrop\FieldTypes\"

#define TOOLBOX_HELPID				1231116

* The following are invalid in object name so we strip them out if we find them in a filename
#define INVALID_OBJNAME_CHARS	" -!@#$%^&*()+={}[]:;?/<>,\|~`'" + ["]


* -- Toolbox localizations
#define TOOL_TEXTPREFIX_LOC				"Texte: "

#define TOOLMENU_RENAME_LOC			"\<Renomme"              		&&R
#define TOOLMENU_DELETE_LOC			"\<Efface"               		&&E
#define TOOLMENU_MODIFY_LOC			"\<Modifie"				&&M
#define TOOLMENU_OPEN_LOC			"\<Ouvre"				&&O
#define TOOLMENU_RUN_LOC			"\<Lance"				&&L
#define TOOLMENU_BROWSE_LOC			"Bro\<wse"				&&w
#define TOOLMENU_CREATEFORM_LOC			"\<Cr�e Forme"				&&C
#define TOOLMENU_ADDTO_LOC			"Ajoute \<a"				&&a
#define TOOLMENU_ADDCATEGORY_LOC		"Ajout Cat�\<gorie"			&&g
#define TOOLMENU_ADDCLASSLIB_LOC		"Ajout Libra\<irie de Classes"		&&i
#define TOOLMENU_REFRESHCATEGORY_LOC	        "Ra\<fraichir Categorie"		&&f
#define TOOLMENU_CUSTOMIZE_LOC			"Personnalisation Bo�te � O\<utils"	&&u
#define TOOLMENU_REFRESH_LOC			"Rafraichir \<Bo�te � Outils"		&&B
#define TOOLMENU_HELPTEXT_LOC			"Affiche l'Ai\<de"			&&d
#define TOOLMENU_ALWAYSONTOP_LOC		"\<Toujours au-dessus"			&&T
#define TOOLMENU_BUILDERLOCK_LOC		"Blocage du Builde\<r"			&&r

#define TOOLMENU_PROPERTIES_LOC			"\<Propri�t�s"				&&P
#define TOOLMENU_FILTERS_LOC			"F\<iltre"				&&i
#define TOOLMENU_NOFILTER_LOC			"rien"
#define TOOLMENU_COPYTOCLIPBOARD_LOC	        "Copie dans le Cli\<pboard"		&&p
#define TOOLMENU_ADDTOFAVORITES_LOC		"Ajoute aux Fa\<voris"			&&v
#define TOOLMENU_ITEMHELP_LOC			"Aid\<e"				&&e
#define TOOLMENU_DOCKED_LOC			"Doc\<k�"				&&k
#define TOOLMENU_OPENOBJECTBROWSER_LOC	        "Ouvre \<dans le Browser objet"		&&d

#define TOOL_NEW_LOC				"\<Nouveau"				&&N

#define TOOL_DELETE_LOC				"�tes vous certain de vouloir supprimer cet item de la Bo�te � Outils?"
#define TOOL_DELETECATEGORY_LOC			"�tes vous certain de vouloir supprimer cette Cat�gorie de la Bo�te � Outils?"
#define TOOL_DELETEFILTER_LOC			"�tes vous certain de vouloir supprimer ce Filtre?"
#define TOOL_REMOVEFAVORITES_LOC		"Enlever des favoris?"

#define TOOL_CREATECATEGORYMSG_LOC		"Nom de la nouvelle cat�gorie:"
#define TOOL_NEWCATEGORY_LOC			"Nouvelle Cat�gorie"
#define TOOL_DUPLICATECATEGORY_LOC		"Nom de Cat�gorie d�ja d�finis."
#define TOOL_DUPLICATEFILTER_LOC		"Nom de Filtre d�ja d�finis."

#define LOCATE_FOLDERNOEXIST_LOC		"Le r�pertoire specifi� n'existe pas." + CHR(10) + CHR(10) + "Faut-il le cr�er?"
#define LOCATE_NOCREATE_LOC			"Impossible de cr�er la table Bo�te � Outils dans le r�pertoire sp�cifi�."
#define LOCATE_NOTFOUND_LOC			"La table Bo�te � Outils  n'a pas �t� trouv�e."

#define ADDCLASSLIB_NOCLASSLIB_LOC		"Vous devez sp�cifier le nom de la librairie de classe a ajouter."
#define ADDCLASSLIB_NOEXIST_LOC			"La librairie de classe sp�cifi�e n'existe pas."

* default new filter name - the '#' is replaced with an actual number
#define NEWFILTER_LOC				"Filtre #"

#define REFRESHING_TOOLBOX_LOC			"Refraichissement de la Bo�te � Outils:"
#define REFRESHING_CATEGORY_LOC			"Refraichissement de la Cat�gorie:"

* for the Customize Toolbox form
#define CUSTOMIZE_ALL_LOC	           	 "<tous>"
#define CUSTOMIZE_CLASSLIBRARIES_LOC		"Librairies des Classes Visual FoxPro"
#define CUSTOMIZE_ACTIVEX_LOC	        	"Contr�les ActiveX"
#define CUSTOMIZE_FILES_LOC	                "Fichiers"

#define CUSTOMIZE_REMOVELIBRARY_LOC		"Voulez vous retirer cette librairie de classes de la Bo�te � Outils?"
#define CUSTOMIZE_REMOVELIBRTITLE_LOC		"Suppression de la Librarie"
#define CUSTOMIZE_ADDLIBRARY_LOC		"Ajour de la Librairie"
#define CUSTOMIZE_REMOVE_LOC			"Enl�ve"

#define CUSTOMIZE_REMOVEALL_LOC			"�tes vous certain de vouloir supprimer tous les outils de cette Cat�gorie?"

#define CUSTOMIZE_ADDBASECLASSES_LOC		"Ajout de toutes les classes de base Visual FoxPro base � cette Cat�gorie?"
#define CUSTOMIZE_GENERAL_LOC			"G�n�ral"
#define CUSTOMIZE_OPTIONS_LOC			"Options"
#define CUSTOMIZE_CLASSOPTIONS_LOC		"Items de Classe"
#define CUSTOMIZE_FILTERS_LOC			"Filtres"
#define CUSTOMIZE_CATEGORIES_LOC		"Cat�gories"

#define CUSTOMIZE_TODEFINENEWFILTER_LOC 	"Pour d�finir un nouveau filtre, click sur le bouton Nouveau Filtre dans la barre d'outils."
#define CUSTOMIZE_NOCURRENTFILTER_LOC	        "(rien - toutes les categories sont visibles)"
#define CUSTOMIZE_FILTERNAMEREQUIRED_LOC 	"Vous devez sp�cifier le nom de ce filtre."

#define CUSTOMIZE_DISCARDCHANGES_LOC		"Abandon des changements dans la Bo�te � Outils?"
#define CUSTOMIZE_NOEXIST_LOC			"La table de la Bo�te � Outils sp�cifi�e n'existe pas."

#define CUSTOMIZE_REFRESHTOOLBOX_LOC		"Voulez-vous rafraichir toutes les cat�gories dans la Bo�te � Outils?"
#define CUSTOMIZE_CLEANUP_LOC			"�tes vous certain de vouloir vider la table de la Bo�te � Outils?"
#define CUSTOMIZE_CLEANUPDONE_LOC		"La table de la Bo�te � Outils � �t� vid�e." + CHR(10) + "Un backup de la table Bo�te � Outils originale a �t� sauv�e sous:"
#define CUSTOMIZE_RESTORE_LOC			"Voulez-vous conserver les items des nouvelles cat�gories et de la Bo�te � Outils qui ont �t� ajout�s" + CHR(10) + "par vous ou achet� � une partie tierce?"
#define CUSTOMIZE_RESTOREDONE_LOC		"La table de la Bo�te � Outils � �t� restaur�e � l'original." + CHR(10) + "Un backup de la Bo�te � Outils originale a �t� sauv�e sous:"

#define CUSTOMIZE_NOEXISTCREATE_LOC		"La Bo�te � Outils sp�cifi�e n'existe pas." + CHR(10) + CHR(10) + "Faut-il la cr�er?"
#define CUSTOMIZE_NOSAVEOPTIONS_LOC		"Impossible de sauvegarder les options courantes de la Bo�te � Outils."

* displayed in place of backed up file if a backup could not be done
#define CUSTOMIZE_NONE_LOC			"<rien>"

#define CUSTOMIZE_DYNAMICCATEGORY_LOC		"Cat�gorie Dynamique - click sur Propri�t� de Cat�gorie pour modifier"


#define CATEGORYREQUIRED_LOC   			"Vous devez sp�cifier le nom de la Cat�gorie."

#define UNABLETOOPEN_LOC			"Impossible d'ouvrir la Bo�te � Outils."

#define ERROR_BADTABLE_LOC			"La table de la Bo�te � Outils � une structure incorrecte:"
#define ERROR_CREATEOBJECT_LOC			"Impossible de cr�er l'objet:"
#define ERROR_CLEANUP_LOC			"Impossible de vider la table Bo�te � Outils suite � l'erreur suivante:"
#define ERROR_RESTORETODEFAULT_LOC		"Impossible de restaurer la table de la Bo�te � Outils originale Unable suite � l'erreur suivante:"
#define ERROR_NOBACKUP_LOC			"Impossible de cr�er un backup de la table Bo�te � Outils en cours." + CHR(10) + CHR(10) + "Voulez-vous toujours continuer?"


#define ERROR_INVALIDCONTAINER_LOC		"Container invalide pour cet objet."
#define ERROR_MEMBERCLASS_LOC			"Impossible de fixer la r�f�rence de classe  pour cet objet."
#define ERROR_NONCONTAINER_LOC			"Impossible d'ajouter des objets � une classe sans container."
#define ERROR_NONVISUALDROP_LOC			"Cette classe n'a pas de repr�sentation visuelle et ne peut d�s lors �tre d�pos�e dans ce ontainer."

#define ERROR_DROPHOOK_LOC			"Erreur rencontr�e en ex�cutant le code _DropHook :"

#define SCAN_REGISTRY_LOC                       "Balayage du registre pour les Composants..."

#define DATAVALUE_CLASSLIBRARY_LOC		"Librairie de Classe "
#define DATAVALUE_CLASSNAME_LOC			"Nom de Classe"
#define DATAVALUE_CONTAINERCLASSLIBRARY_LOC	"Classe Parent"
#define DATAVALUE_CONTAINERCLASSNAME_LOC	"Nom de la classe Parent"

#define DATAVALUE_OBJECTNAME_LOC		"Nom de l'Objet"
#define DATAVALUE_PARENTCLASS_LOC		"Classe Parent"
#define DATAVALUE_BASECLASS_LOC			"Classe de Base"
#define DATAVALUE_FILENAME_LOC			"Nom du fichier"
#define DATAVALUE_TABLENAME_LOC			"Table"
#define DATAVALUE_FIELDNAME_LOC			"Champs"
#define DATAVALUE_PROPERTIES_LOC		"Propri�t�s"
#define DATAVALUE_COMCOMPONENT_LOC		"Composant COM"
#define DATAVALUE_REFRESHCATEGORY_LOC		"Refraichissement de la categorie apr�s ex�cution de l'application"
#define DATAVALUE_BUILDER_LOC			"Assembleur"

#define DATAVALUE_TEXTSCRAP_LOC			"Texte de commentaire"
#define DATAVALUE_SCRIPT_LOC			"Script"
#define DATAVALUE_COMPLETESCRIPT_LOC		"D�placement du script complet"
#define DATAVALUE_TEXTMERGE_LOC			"Evaluation d'utilisation de m�lange de texte"

* used by _WebServiceCategory behavior class
#define DATAVALUE_TEMPLATE_LOC			"Mod�le"

* used by _WebService behavior class
#define DATAVALUE_WSDL_LOC			"WSDL"
#define DATAVALUE_URI_LOC			"URI"
#define DATAVALUE_PORT_LOC			"Port"
#define DATAVALUE_SERVICE_LOC			"Service"
#define DATAVALUE_WSML_LOC			"WSML"
#define DATAVALUE_CLASS_LOC			"Classe"


* used in _foldercategory
#define DATAVALUE_FOLDER_LOC			"Folder"
#define DATAVALUE_FILETYPES_LOC			"Type de fichier"


* -- Used in the ToolboxProperties form
#define PROPERTIES_NONAME_LOC			"Le nom est n�cessaire."
#define PROPERTIES_NOTOOLNAME_LOC		"Vous devez sp�cifier le nom de l'item."
#define PROPERTIES_NOCATEGORYNAME_LOC		"Vous devez sp�cifier le nom de la Cat�gorie."

* displayed in help while loading
#define LOADING_LOC				"Chargement de la Bo�te � Outils ..."

#define YES_LOC					"Oui"
#define NO_LOC					"Non"

#define MENU_RENAMEITEM_LOC			"Item Renomm�"
#define MENU_DELETEITEM_LOC			"Item Effac�"
#define MENU_MODIFYITEM_LOC			"Modification d'un Item"
#define MENU_ADDCATEGORY_LOC			"Ajout Cat�gorie"
#define MENU_SELECTALL_LOC			"S�lection \<TOUT"
#define MENU_DESELECTALL_LOC			"\<Efface TOUT"
#define MENU_SORTALPHA_LOC			"\<Tri Alphab�tique"
#define MENU_REMOVE_LOC				"\<Enl�ve"
#define MENU_REMOVEALL_LOC			"E\<nl�ve TOUT"
#define MENU_PROPERTIES_LOC			"\<Propr�t�s d'un Item"


* used by CFoxFileTypesCombo class
#define FILETYPE_ALL_LOC			"Tout les fichiers (*.*)"
#define FILETYPE_COMMON_LOC			"Commun (*.scx;*.vcx;*.prg;*.frx;*.lbx;*.mnx;*.dbc;*.qpr;*.h)"
#define FILETYPE_SOURCE_LOC			"Toute Source (*.scx;*.vcx;*.prg;*.frx;*.lbx;*.mnx;*.dbc;*.dbf;*.cdx;*.qpr;*.h)"
#define FILETYPE_FORMS_LOC			"Formes et Classes (*.scx;*.vcx;*.prg)"
#define FILETYPE_REPORTS_LOC			"Rapports and �tiquettes (*.frx;*.lbx)"
#define FILETYPE_MENUS_LOC			"Menus (*.mnx)"	
#define FILETYPE_PROGRAMS_LOC			"Programmes (*.prg;*.h;*.qpr;*.mpr)"				
#define FILETYPE_DATA_LOC			"Structures Data (*.dbc;*.dbf;*.cdx)"
#define FILETYPE_PROJECTS_LOC			"Projets (*.pjx)"
#define FILETYPE_TEXT_LOC			"Texte (*.txt;*.xml;*.xsl;*.htm;*.html;*.log;*.asp;*.aspx)"
#define FILETYPE_IMAGES_LOC			"Images (*.ani;*.bmp;*.cur;*.dib;*.gif;*.ico;*.jpg)"


* used by the CBaseClassCombo class
#define UNKNOWN_LOC				"<inconnu>"

* message to display before changing the Member Class properties of an object
#define MEMBERCLASS_WARNING_LOC			"En utilisant cette classe, elle d�truira les membres existant actuels de la classe" + CHR(10) + "et en 						recr�era des nouveaux bas�s sur les nouvelles valeurs." + CHR(10) + CHR(10) + "Il en r�sultera une perte de 						donn�es des propri�t�s, nouveau, ajout�, et/ou modifi�" + CHR(10) + "methode code, et objets ajout�s." + CHR(10) 						+ CHR(10) + "Voulez-vous continuer?"
#define HEADERCLASS_WARNING_LOC			"En utilisant cette classe, elle d�truira l'en-t�te de classe actuelle" + CHR(10) + "et recr�era  de nouvelle 								valeurs." + CHR(10) + CHR(10) + "Il en r�sultera une perte de donn�es des propri�t�s, nouveau, ajout�, et/ou 								modifi�" + CHR(10) + "methode code, et objets ajout�s." + CHR(10) + CHR(10) + "Voulez-vous continuer?"

#define DROPOBJECT_CREATECOLUMN_LOC		"Voulez-vous ajouter une colonne � la grille pour contenir ce contr�le?"
#define DROPOBJECT_REMOVETEXT1_LOC		"Voulez-vous remplacer le contr�le par d�faut Text1 par celui que vous �ditez dans cette colonne?"


#define EDITDROPTEXT_CAPTION_LOC		"Mod�le de texte Tirer Coller"
#define EDITCTRLDROPTEXT_CAPTION_LOC		"Ctrl+Mod�le de Texte Tirer Coller"

* used in CFoxBuilderCombo class
#define BUILDER_DEFAULT_LOC			"Utiliser les param�tres blocage de l'Assembleur"
#define BUILDER_ALWAYSRUN_LOC			"Toujours invoquer l'Assembleur"
#define BUILDER_NEVERRUN_LOC			"Ne jamais invoquer l'Assembleur"

#define PROPERTY_REMOVE_LOC			"�tes vous certain de vouloir supprimer ces param�tres de propri�t�?"
#define PROPERTY_REMOVECAPTION_LOC		"Enl�ve"

#define CLASS_SETDEFAULT_LOC			"�tes vous certain de vouloir supprimer compl�tement cette classe s�lectionn�e?"