*=======================================================
* frxCursor.vcx compile constants
*=======================================================

#include foxpro_reporting.h

*-------------------------------------------------------
* Magic numbers
*-------------------------------------------------------

*-- Report Layout object dimensions
*--
#define BAND_SEPARATOR_HEIGHT_FRUS	 	2083.333
#define BAND_SEPARATOR_HEIGHT_PIXELS	20

*-- Object Cursor filter modes:
*--
#define OBJCSR_ALL_OBJECTS_IGNORE_GROUPS	0
#define OBJCSR_FILTER_ON_SELECTED			1
#define OBJCSR_SHOW_ALL_OBJECTS				2
#define OBJCSR_FILTER_GROUP					3

#define OBJCSR_SORTORDER_TYPE		        1
#define OBJCSR_SORTORDER_BAND		        2

#define FRX_OBJTYPE_MULTISELECT             99

*-------------------------------------------------------
* Localization strings 
*-------------------------------------------------------

*-- FRX object targets:
*--
#define TARGET_MULTISELECT_LOC		"S�lection multiple"
#define TARGET_REPORT_COMMENT_LOC   "Commentaire"
#define TARGET_REPORT_GLOBAL_LOC	"�tat/Global"
#define TARGET_WORKAREA_LOC			"Zone de travail"
#define TARGET_INDEX_LOC			"Index"
#define TARGET_RELATION_LOC			"Relation"	
#define TARGET_TEXT_LABEL_LOC		"Etiquette"
#define TARGET_LINE_LOC				"Ligne"
#define TARGET_BOX_LOC				"Rectangle"
#define TARGET_FIELD_LOC			"Champ"
#define TARGET_TITLE_LOC			"Titre"
#define TARGET_PAGE_HEADER_LOC		"En-t�te de page"
#define TARGET_COL_HEADER_LOC		"En-t�te de colonne"
#define TARGET_GROUP_HEADER_LOC		"En-t�te de groupe"
#define TARGET_DETAIL_LOC			"D�tail"
#define TARGET_GROUP_FOOTER_LOC		"Pied de groupe"
#define TARGET_COL_FOOTER_LOC		"Pied de colonne"
#define TARGET_PAGE_FOOTER_LOC		"Pied de page"
#define TARGET_SUMMARY_LOC			"Sommaire"
#define TARGET_DETAIL_HEADER_LOC	"En-t�te de bande d�tail"
#define TARGET_DETAIL_FOOTER_LOC	"Pied de bande d�tail"
#define TARGET_UNKNOWN_BAND_LOC		"Bande de type inconnu"
#define TARGET_GROUPED_LOC			"Objets group�s"
#define TARGET_PICTURE_LOC			"Image/OLE Bound"
#define TARGET_VARIABLE_LOC			"Variable"
#define TARGET_PDRIVER_LOC			"Param�tre d'impression"
#define TARGET_FONTRESO_LOC			"Polices"
#define TARGET_DATAENV_LOC			"Environnement de donn�es"
#define TARGET_CURSOR_LOC			"Cursor"
#define TARGET_UNKNOWN_LOC			"Cible de type inconnu"

#define TARGET_FORCED_PAGEHEADER_LOC "Traduit comme ent�te de Page"
#define TARGET_UNPREDICTABLE_LOC     "Comportement ind�termin�"

*-- Calculation "Reset On" combo list
*--
#define ENDOFREPORT_LOC		    "�tat"
#define ENDOFPAGE_LOC		    "Page"
#define ENDOFCOLUMN_LOC		    "Colonne"
#define GROUP_BY_LOC		    "Groupe : "
#define DETAIL_LOC              "D�tail "
#define NEW_LOC                 "nouveau"


*-- Messagebox error messages:
*--
#define METADATA_DOM_ERROR_LOC   "Erreur d'exception dans frxCursor::getMetadataDomDoc()"
#define CREATE_IC_FAILURE_LOC    "Impossible de cr�er le device context. CreateIC() a renvoy� 0."