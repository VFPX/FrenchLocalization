* locs for VCX super-classes

#DEFINE OUTPUTCLASS_APPNAME_LOC              "Classe VFP de sortie d'�tat"

#DEFINE OUTPUTCLASS_CONFIGTABLECREATED_LOC     "La table de configuration "+ lcDBF + " vient d'�tre cr��e."
                                                                                                "a �t� sauv�e sur le disque."
#DEFINE OUTPUTCLASS_CONFIGTABLEWRONG_LOC     "La table de configuration n'a pas un format correct."

* this is different from XML because in the XML class they
* are used in SEEK() and require specific tagnames, whereas
* the superclasses just require certain indexes for optimizing LOCATES,

#DEFINE OUTPUTCLASS_CONFIGINDEXMISSING_LOC   "Il manque un ou plusieurs index "+ CHR(13) + ;
                                                                                                   "� la table de configuration."

#DEFINE OUTPUTCLASS_INITSTATUS_LOC           "En cours d'initialisation... "
#DEFINE OUTPUTCLASS_PREPSTATUS_LOC           "En cours : passe de calculs... "
#DEFINE OUTPUTCLASS_RUNSTATUS_LOC            "Sortie en cours de cr�ation... "
#DEFINE OUTPUTCLASS_TIME_SECONDS_LOC         SPACE(1) + "seconde(s)"
#DEFINE OUTPUTCLASS_CANCEL_INSTRUCTIONS_LOC  "Taper Echap pour abandonner... "
#DEFINE OUTPUTCLASS_REPORT_CANCELQUERY_LOC   "Arr�ter l'ex�cution de l'�tat?"+CHR(13) + ;
                                             "(Si vous r�pondez 'Non', l'ex�cution se poursuivra.)"
#DEFINE OUTPUTCLASS_REPORT_INCOMPLETE_LOC    "L'ex�cution de l'�tat a �t� abandonn�e." + CHR(13) + ;
                                             "Vos r�sultats ne sont pas complets."

#DEFINE OUTPUTCLASS_SUCCESS_LOC              THIS.AppName+" a cr�� votre �tat sous le nom"+;
                                             CHR(13)+THIS.TargetFileName+"." + CHR(13) + ;
                                             IIF(THIS.AllowModalMessages,;
                                              "R�pondez 'Oui' pour enregistrer" + CHR(13) + ;
                                             "ce nom de fichier dans le presse papier.","")

#DEFINE OUTPUTCLASS_NOFILECREATE_LOC         "Le fichier " + THIS.TargetFileName+" ne peut �tre cr��."

#DEFINE OUTPUTCLASS_CREATEERRORS_LOC         THIS.AppName+" a cr�� votre �tat sous le nom"+ ;
                                             CHR(13)+THIS.TargetFileName+". "+CHR(13)+ ;
                                             "Cependant, une erreur s'est produite pendant le processus." + CHR(13) + ;
                                             OUTPUTCLASS_REPORT_INCOMPLETE_LOC

#DEFINE OUTPUTCLASS_NOCREATE_LOC             THIS.AppName +" n'a pas pu cr�er votre �tat."
 
#DEFINE OUTPUTCLASS_ERRNOLABEL_LOC           "Erreur :         "
#DEFINE OUTPUTCLASS_ERRPROCLABEL_LOC         "M�thode :     "
#DEFINE OUTPUTCLASS_ERRLINELABEL_LOC         "Ligne :          " 

* the following loc is eval'd for updateListener's actual progress bar message.  
* In most cases,
* changing this value is overkill, as the localizable portions of
* the message are already localized as separate properties.
* All the status messagse as well as the therm caption can
* also be set at runtime without touching the locs.
#DEFINE OUTPUTCLASS_THERMCAPTION_LOC        [cMessage+ " "+ TRANSFORM(INT(THIS.PercentDone*100)) + "%" ] + ;
                                            [+ IIF(NOT THIS.IncludeSeconds, "" , " "+] + ;
                                            [TRANSFORM(IIF(THIS.IsRunning,DATETIME(), THIS.ReportStopRunDateTime)-] + ;
                                            [THIS.ReportStartRunDateTime)+" " + THIS.SecondsText)]


* locs for XML Listener class:

#DEFINE OUTPUTXML_APPNAME_LOC               "XML Listener"

#DEFINE OUTPUTXML_CONFIGTAGMISSING_LOC      "Au moins un des crit�res d'index requis est manquant "+ CHR(13) + ;
                                            "dans la table de configuration."

#DEFINE OUTPUTXML_FRXMISSING_LOC            "le curseur FRX requis n'est pas accessible." 
   
   
#DEFINE OUTPUTXML_FRXCURSOR_MISSING_LOC     "L'objet FRX cursor n'a pas �t� trouv� dans " + CHR(13)+ ;
                                            "_FRXCURSOR.VCX, "+CHR(13)+ ; 
                                            "_REPORTOUTPUT." + CHR(13) + CHR(13)+ ;
                                            "Quelques possibilit�s peuvent manquer � cette classe."   

* locs for XML Display Listener Class:

#DEFINE OUTPUTXMLDISPLAY_APPNAME_LOC        "XML Display Listener"

* locs for HTML:

#DEFINE OUTPUTHTML_APPNAME_LOC              "HTML Listener"