* locs for REPORTOUTPUT.APP

#DEFINE OUTPUTAPP_APPNAME_LOC    "VFP Report Output Application"

#DEFINE OUTPUTAPP_CONFIGTABLEBROWSE_LOC    "Table de configuration de d'�tat"

#DEFINE OUTPUTAPP_CONFIGTABLEWRONG_LOC     "La table de configuration specifi�e  pour " + ;
                                           OUTPUTAPP_APPNAME_LOC + CHR(13) + ;
                                           "n'a pas �t� trouv�e ou est dans un format inad�quat." 

#DEFINE OUTPUTAPP_UNKNOWN_ERROR_LOC       "Une erreur d'origine inconnue s'est produite dans " + OUTPUTAPP_APPNAME_LOC
   
