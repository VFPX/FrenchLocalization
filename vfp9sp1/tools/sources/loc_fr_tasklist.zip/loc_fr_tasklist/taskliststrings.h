#ifndef __TASKLISTSTRINGS_H
#define __TASKLISTSTRINGS_H

*-- TaskListStrings header file
#define APP_TITLE_LOC			"Liste des t�ches"	&&"Task List"
#define APP_CAPTION_LOC			"T�ches"	&&"Tasks"

*-- Context Menu Strings
*-- \< Indicates hot key

#define CTM_SPACER			"\-"

#define CTM_OPEN_TASK_LOC 		"Ouvrir une \<t�che"	&&"Open \<Task"
#define CTM_PRINT_LOC			"Im\<primer"	&&"\Print"
#define CTM_OPEN_FILE_LOC		"Ouvrir le \<fichier "	&&"Open \<File "
#define CTM_IMPORT_LOC			"\<Importer..."	&&"\Import Tasks..."
#define CTM_EXPORT_LOC			"\<Exporter..."	&&"\Export Task..."
#define CTM_COMPLETE_LOC		"\<Marquer comme termin�e"	&&"\<Mark as Complete"
#define CTM_UNREAD_LOC			"Mar\<quer comme non lue"	&&"Mar\<k as Unread"
#define CTM_READ_LOC			"Mar\<quer comme lue"	&&"Mar\<k as Read"
#define CTM_DELETE_LOC			"\<Supprimer la t�che"	&&"\<Delete Task"
#define CTM_SHOWTASKS_LOC		"Affic\<her les t�ches"	&&"\<Show Tasks"
#define CTM_COLUMNCHOOSER_LOC	"Choix des \<colonnes..."	&&"\<Column Chooser..."
#define CTM_REMOVECOLUMN_LOC	"Supprime\<r cette colonne"	&&"\<Remove This Column"
#define CTM_OPTIONS_LOC			"\<Options"

#define CTM_SHORTCUTS_LOC		"Raccourcis"	&&"Shortcuts"
#define CTM_USERDEFINED_LOC		"T�ches utilisateur"	&&"User Defined Tasks"
#define CTM_OTHER_LOC			"Autres t�ches"	&&"Other Tasks"

#define CLICK_HERE_LOC		"Cliquer ici pour ajouter une t�che"	&&"Click here to add a new task"

*-- Other products
#define OP_MS_OUTLOOK_LOC	"MS Outlook"
#define OP_MS_PROJECT_LOC	"MS Project"
#define OP_MS_EXCEL_LOC		"MS Excel"
#define OP_MS_VID_LOC		"MS Visual InterDev"
#define OP_MS_VS_LOC		"MS Visual Studio 7.0"

#define ERROR_OCCURRED_LOC	"Erreur d'ex�cution."	&&"A run-time error occurred."
#define ERROR_ERROR_LOC		"Erreur:"	&&"Error:"
#define ERROR_METHOD_LOC	"M�thode:"	&&"Method:"
#define ERROR_LINE_LOC		"Ligne:"	&&"Line:"
#define ERROR_QUERY_LOC		"Une erreur est survenue durant cette requete. La liste des t�ches sera ferm�e."	&&"An error occurred during the requery. The tasklist will be closed."
#define ERROR_DUPFIELD_LOC	"Un champ a �t� dupliqu� dans les tables principales et UDF. La table UDF a �t� supprim�e."	&&"A field was duplicated in the main and UDF tables. The UDF table has been removed."
#define ERROR_PACKDBF		"L'acc�s exclusif � la table de la liste des t�ches pour le nettoyage n'a pas �t� obtenu. Celle ci est probablement ouverte dans une autre session de Visual FoxPro."	&&"Cannot get exclusive access to Task List table for cleanup.  It may be open in another session of Visual FoxPro."
#DEFINE ERROR_NOINIT_LOC	"Impossible d'initialiser la liste des t�ches. Assurez vous de la disponibilit� de la table des t�ches."	&&"Unable to initialize the Task List. Make sure the task table is available."

#define DELETE_TASK_LOC		"Confirmez-vous la suppression de cette t�che?"	&&"Are you sure you want to delete this task?"

#define PRIORITY_HIGH_LOC	"Haute"	&&"High"
#define PRIORITY_NORMAL_LOC	"Normale"	&&"Normal"
#define PRIORITY_LOW_LOC	"Basse"	&&"Low"

#define DEFCOL_ID_LOC		"ID"
#define DEFCOL_CONTENTS_LOC	"Contenu"	&&"Contents"
#define DEFCOL_FILENAME_LOC	"Nom de fichier"	&&"File Name"
#define DEFCOL_DUEDATE_LOC	"Date de remise"	&&"Due Date"
#define DEFCOL_PRIORITY_LOC	"!"

*-- Custom formats for the Microsoft Date Time Picker control
#define DATE_FORMAT_LOC			"d/M/yyy"	&&"M/d/yyy"
#define DATETIME_FORMAT_LOC		"d/M/yyy hh:mm:ss"	&&"M/d/yyy hh:mm:ss"
#define TIME_FORMAT_LOC			" hh:mm:ss"

#define TASK_TYPE_SHORTCUT_LOC		"Raccourci"	&&"Shortcut"
#define TASK_TYPE_OTHER_LOC			"Autre t�che"	&&"Other Task"
#define TASK_TYPE_USERDEFINED_LOC	"T�che utilisateur"	&&"User-Defined Task"

#define TASKPROPERTIES_LOC		"Propri�t�s de la t�che"	&&"Task Properties"
#define TASK_LOC				"T�che"	&&"Task"      		&& to-do
#define FIELDS_LOC				"Champs"	&&"Fields"    		&& table columns
#define CONTENTS_LOC			"Contenus"	&&"Contents"  		&& what's inside
#define FILENAME_LOC			"Nom de fichier"	&&"File Name"
#define CLASS_LOC				"Classe"	&&"Class"     		&& object definition
#define METHOD_LOC				"M�thode"	&&"Method"			&& function
#define LINE_LOC				"Ligne"	&&"Line"				&& line number
#define DUEDATE_LOC				"Date de remise"	&&"Due Date"
#define PRIORITY_LOC			"Priorit�"	&&"Priority"
#define READ_LOC				"Lue"	&&"Read"				&& Read/Unread
#define COMPLETE_LOC			"Termin�e"	&&"Complete"

#define APP_TITLE				"Tasks"
#define BROWSE_LOC				"Lister"	&&"\<Browse"
#define OK_LOC					"OK"
#define CANCEL_LOC				"Annuler"	&&"Cancel"
#DEFINE CLOSE_LOC				"Fermer"	&&"Close"
#define APPLY_LOC				"\<Appliquer"	&&"\<Apply"
#define ELIPSES_LOC				"..."
#define OPTIONS_LOC				"Options de la liste des t�ches"	&&"Tasklist Options"
#define CLEAR_LOC				"N\<ettoyer"	&&"\<Clear"
#define NEW_LOC					"\<Nouvelle"	&&"\<New"
#define MODI_LOC				"Mo\<difier la structure"	&&"\<Edit Structure"
#define UDF_COLUMN_LOC			"Table des C\<olonnes utilisateur"	&&"\<User-defined column table"
#define FILE_LOC				"Fichier"	&&"File"
#define CLEANUP_LOC 			"Nettoyer les t�ches \<Fox"	&&"Clean Up \<FoxTask"

#define MSGBOX_CLEANUP			"Cette option r�initialise votre table des t�ches. Continuer?"	&&"This option cleans up your FoxTask table. Proceed?"

#define FILE_NOT_EXIST_LOC		"Le fichier associ� avec ce raccourci n'existe pas."+chr(13)+"Voulez-vous supprimer ce raccourci?"	&&"The file associated with this shortcut does not exist." + ;
								Chr(13) +  "Would you like to delete this shortcut?"

#define BAD_CHILD_DATA_LOC		"La table choisie est ou inaccessible ou n'est pas compatible."+chr(13)+chr(13)+"Veuillez consulter la documentation pour de plus amples d�tails"+chr(13)+"au sujet des sources de donn�es utilisateur."	&&"The table chosen is either not accessible or " + Chr(13) + ;
&&								"does not meet the requirements for Tasklist data sources." + Chr(13) + Chr(13) + ;
&&								"Please review the documentation for more" + Chr(13) + ;
  &&								"information about user-defined data sources."

#define ERROR_NO_FILENAME_LOC	"le nom de fichier n'a pas d'association."	&&"No association could be determined for the filename passed."
#define ERROR_BAD_ASSOC_LOC		"L'application associ�e avec cette t�che ne peut pas l'ouvrir"	&&"The application associated with this task could not open the task."
#define ERROR_NO_APP_LOC		"Il n'y a pas d'application associ�e � cette t�che."	&&"There is no application associated with this task."
#define ERROR_APP_BUSY_LOC		"L'application associ�e � cette t�che est occup�e."	&&"The application associated with this task is busy."
#define ERROR_FAIL_LOAD_LOC		"L'application associ�e � cette t�che ne peut �tre charg�e."	&&"The application associated with this task failed to load."

#DEFINE ERROR_NOCREATEFILE_LOC	"La table @@ ne peut �tre cr��e"	&&"The table @@ could not be created."
	
#endif