* frmPaneManager.setpane
#define PANEL_UNABLE_LOC		"Impossible de cr�er le panneau: "
* foxpane/cmdrefresh.Init (ajout de la proc pour caption). Je n'ai rien fait pour option car idem fr
#define PANELREFRESH_CAPTION_LOC "Actua\<liser"
* foxpaneoptions.vcx optionspage_content (ajout du fichier inclu foxpane.h) Cfoxlabel5
#define	PANEL_OPTIONLABELEXP_LOC	"Vous pouvez d�finir les options suivantes pour ce fournisseur de contenu:"
* foxpaneoptions.vcx optionspage_customize)
* tout � faire
* ajout du fichier inclu foxpane.h
* Init
#define PANEL_CMDINSTALL_LOC	"Installer"
#define PANEL_CMDCUSTOMIZE_LOC "Personnaliser"
#define PANEL_CMDCLEANUP_LOC	"Nettoyer"
#define PANEL_CMDRESTOREDEFAULT_LOC	"Restaurer"
#define PANEL_LBLINSTALLPANE_LOC	"Installer un panneau porvenant d'un manifeste fournit par Microsoft ou un tiers"
#define PANEL_LBLCUSTOMIZEPANE_LOC	"Cr�er ou modifier les panneaux"
#define PANEL_LBLCLEANUPPANE_LOC	"Supprimer les enregistrements marqu�s des tables de gestion et nettoyer le cache"
#define PANEL_LBLRESTOREDEFAULT_LOC	"Restaurer le centre d'informations � ses valeurs d'origine"
#define PANEL_LBLTABLESMANAGERFOLDER_LOC	"Dossier des tables de gestion du contenu du centre d'informations:"
#define PANEL_LBLCACHEFOLDER_LOC	"Dossier cache:"

*foxpaneoptions.vcx
*tout � faire
*optionspage_general
#define	 PANELGEN_HOMEPAGE_LOC "Page d'accueil"
#define	  PANELGEN_DEFHOMEPAGE_LOC "d�finir la page d'accueil du centre d'informations"
#define	  PANELGEN_PANEL_LOC	"panneau:"
#define	  PANELGEN_REFRESHCONTENT_LOC	"Actualisation du contenu"
#define	  PANELGEN_OPT1_LOC "A chaque d�marrage du centre d'informations"
#define	  PANELGEN_OPT2_LOC "A chaque activation du panneau"
#define	  PANELGEN_OPT3_LOC "Tous les x jours"
#define	  PANELGEN_OPT4_LOC "Jamais"
#define	 PANELGEN_TIMEOUT_LOC "D�lai d'attente du contenu Internet :"
#define	 PANELGEN_SECONDS_LOC	"secondes"
#define	 PANELGEN_STARTOPTION_LOC	"Ouvrir le centre d'informations au d�marrage de Visual FoxPro"
*foxpaneoptions.vcx
* optionspage_pane
* fichier � inclure ...
#define	 	PANELPANE_TITLE_LOC	"Titre du panneau"
#define	  PANELPANE_DISPLAYCONTENT_LOC	"Vous pouvez d�finir quel contenu est affich� sur ce panneau"
#define	  PANELPANE_NOCONTENT_LOC	"Il n'y a rien � param�trer pour ce panneau"
#define	 PANELPANE_CHECKCONTENT_LOC	"Actualisation du contenu"

#define	 PANELPANE_OPT1_LOC	"Valeur par d�faut"
#define	 PANELPANE_OPT2_LOC	"A chaque d�marrage du centre d'informations"
#define	 PANELPANE_OPT3_LOC	"A chaque activation du panneau"
#define	 PANELPANE_OPT4_LOC	"Tous les x jours"
#define	 PANELPANE_OPT5_LOC	"Jamais"
#define	 PANELPANE_HELP_LOC	"Aide"

* optionspage_proxy
* idem
#define	 PANELPROXY_TITLE_LOC	"Options Proxy"
#define	 PANELPROXY_EXPLAIN_LOC	"D�finir les param�tres d'utilisation d'un serveur proxy pour l'acc�s au contenu Internet et aux services Web"
#define	 PANELPROXY_OPT1_LOC	"N'utilise pas de serveur proxy"
#define	 PANELPROXY_OPT2_LOC	"Utilise les param�tres du navigateur par d�faut"
#define	 PANELPROXY_OPT3_LOC	"Utiliser les param�tres suivants:"

#define	 PANELPROXY_ADDRESS_LOC	"Adresse:"
#define	 PANELPROXY_PORT_LOC	"Port:"
#define	 PANELPROXY_USER_LOC	"Utilisateur:"
#define	 PANELPROXY_PASSWD_LOC	"Mot de passe:"
