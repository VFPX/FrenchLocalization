#include fr_loc_foxpane.h

#define NEWLINE				CHR(13) + CHR(10)

* update this if we change how the Panes are published
#define PUBLISH_VERSION		1.0

#define FOXPANE_HELPID			1231117
#define OPTIONS_HELPID			1231125
#define CUSTOMIZE_HELPID		1231126

* MSXML DOM parser
#define MSXML_PARSER		"MSXML2.DOMDocument.4.0"

* these can be used in the Data section of a content section
* 	<!-- CONTENT --> = inserts all subcontent at specified position
*   <!-- WRAPPANE --> = wrap the sub-content in XML tags
#define VFP_CONTENT			"<!-- CONTENT -->"
#define VFP_XMLCONTENT		"<!-- XMLCONTENT -->"

#define PANETYPE_XML		'X'
#define PANETYPE_HTML		'H'
#define PANETYPE_FOX		'F'
#define PANETYPE_WEBPAGE	'W'
#define PANETYPE_UNDEFINED	' '

#define RENDERTYPE_XML		'X'
#define RENDERTYPE_HTML		'H'
#define RENDERTYPE_FOX		'F'
#define RENDERTYPE_WEBPAGE	'W'
#define RENDERTYPE_NONE		' '

* Source of XML, XSL, CSS
#define SRC_MEMO			'M'
#define SRC_FILE			'F'
#define SRC_URL				'U'
#define SRC_SCRIPT			'S'
#define SRC_WEBSERVICE		'W'
#define SRC_XML				'X'
#define SRC_NONE			' '


#define XFORM_TYPE_XSL		'X'
#define XFORM_TYPE_SCRIPT	'S'
#define XFORM_TYPE_NONE		' '

#define INFOTYPE_CONTENT	'C'
#define INFOTYPE_FILE		'F'

#define REFRESHFREQ_PANELOAD	0
#define REFRESHFREQ_DEFAULT		-1
#define REFRESHFREQ_TASKLOAD	-2
#define REFRESHFREQ_NEVER		-99

* used by the ShellTo method
#define SW_HIDE             0
#define SW_SHOWNORMAL       1
#define SW_NORMAL           1
#define SW_SHOWMINIMIZED    2
#define SW_SHOWMAXIMIZED    3
#define SW_MAXIMIZE         3
#define SW_SHOWNOACTIVATE   4
#define SW_SHOW             5
#define SW_MINIMIZE         6
#define SW_SHOWMINNOACTIVE  7
#define SW_SHOWNA           8
#define SW_RESTORE          9
#define SW_SHOWDEFAULT      10
#define SW_FORCEMINIMIZE    11
#define SW_MAX              11
#define SE_ERR_NOASSOC 		31

#DEFINE INTERNET_OPEN_TYPE_PRECONFIG	0
#DEFINE INTERNET_OPEN_TYPE_DIRECT 		1
#DEFINE INTERNET_OPEN_TYPE_PROXY		3
#DEFINE INTERNET_SYNCHRONOUS			0
#DEFINE INTERNET_FLAG_RELOAD			2147483648
* #define INTERNET_FLAG_KEEP_CONNECTION	

#define tvwFirst	0
#define tvwLast		1
#define tvwNext		2
#define tvwPrevious	3
#define tvwChild	4


* when found in the XML/XSL, will load external file
* rather than using the text here
#define LOADFILE_MACRO			"FILE="


* used to encode fields when publishing
#define PUBLISH_ENCODE_START		"!!ENC!!"
#define PUBLISH_ENCODE_END			"??ENC??"


#define APPNAME_LOC						"Centre d'informations"
#define RENDER_NOCONTENT_LOC			"-pas de contenu d�fini-"

#define MENU_OPTIONS_LOC				"\<Options..."
#define MENU_PUBLISH_LOC				"\<Publier"
#define MENU_RELOAD_LOC					"\<Recharger"

#define	OPTIONS_LASTOPENPANE_LOC		"<dernier panneau ouvert>"


#define PROXY_NONE			1
#define PROXY_IE			2
#define PROXY_CUSTOM		3


#define OPTIONS_TASKPANE_LOC			"Param�tres du centre d'informations"
#define OPTIONS_GENERAL_LOC				"G�n�ral"
#define OPTIONS_CUSTOMIZE_LOC			"Personaliser"
#define OPTIONS_PROXY_LOC				"Proxy Server"


* don't localize the #description# macro
#define CONNECTING_LOC					"Connexion � #description#..."

#define PANEDIRECTORY_NOEXIST_LOC	"le dossier sp�cifi� pour les tables du centre d'informations n'existe pas." + CHR(10) + CHR(10) + "Voulez-vous le cr�er?"
#define CACHEDIRECTORY_NOEXIST_LOC	"le dossier sp�cifi� pour les fichiers caches n'existe pas." + CHR(10) + CHR(10) + "Voulez-vous le cr�er?"

#define ASK_RESTORETODEFAULT_LOC	"Etes-vous s�r de vouloir restaurer les tables de votre centre d'informations � leurs valeurs par d�faut?" + CHR(10) + "(toutes vos am�nagements seront perdus)"
#define RESTORETODEFAULT_LOC		"Le centre d'information a �t� initialis� � ses valeurs d'origine."

#define ASK_CLEANUP_LOC				"Etes-vous s�r de vouloir nettoyer les tables du centre d'informations?"

#define ERROR_RESTORETODEFAULT_LOC	"Impossible de r�initialiser les tables � cause de l'erreur suivante:"
#define ERROR_OPENTASKPANE_LOC		"Ouverture ou cr�ation de la table taskpane impossible."
#define ERROR_OPENCONTENT_LOC		"Ouverture ou cr�ation de la table panecontent impossible."
#define ERROR_OPENTABLE_LOC			"Impossible de charger le gestionnaire du centre d'informations pour la raison suivante:"
#define ERROR_RESTORE_LOC			"Voulez-vous restaurer � l'emplacement par d�faut?"
#define ERROR_BADDIR_LOC			"le nom de dossier n'est pas valide."
#define ERROR_CREATETABLES_LOC		"la cr�ation de table a rencontr� l'erreur suivante :"

#define ERROR_CLEANUP_LOC			"Impossible de nettoyer les tables � cause de l'erreur suivante :"
#define ERROR_NOBACKUP_LOC			"La sauvegarde des tables du centre d'informations a �chou�." + CHR(10) + CHR(10) + "Voulez-vous malgr� tout continuer?"


#define ERROR_INITERROR_LOC			"L'initialisation du gestionnaire a �chou�."
#define ERROR_SCRIPT_LOC			"Erreur d'ex�cution du script de g�n�ration de contenu."
#define ERROR_WSCONNECT_LOC			"Connexion au service Web impossible: "
#define ERROR_WSMETHOD_LOC			"Erreur d'ex�cution du service Web: "

#define LINK_CONFIGURE_LOC			"Configurer"

#define WORKING_OFFLINE_LOC			"[travail en d�connect�]"

* use by FoxPaneLocate form
#define LOCATE_FOLDERNOEXIST_LOC	"le dossier sp�cifi� n'existe pas."
#define LOCATE_NOCREATE_LOC			"La cr�ation des tables dans le dossier sp�cifi� est impossible."
#define LOCATE_FOLDEREXISTS_LOC		"le dossier du centre d'information existe deja dans le dossier sp�cifi�."

* set startup messages
#define STARTUP_MSG1_LOC			"Le point de d�part de l'application est :"
#define STARTUP_MSG2_LOC			"Voulez-vous le positionner au centre d'informations?"

#define SETUP_DELETEPANE_LOC		"Confirmez-vous la suppression de ce panneau?"
#define SETUP_DELETECONTENT_LOC		"Confirmez-vous la suppression du contenu de ce panneau?"
#define SETUP_COMMONFILES_LOC		"<fichiers communs>"
#define SETUP_REMOVEFILE_LOC		"Confirmez-vous la suppression de ce fichier?"
#define SETUP_FILENAME_LOC			"Nom de fichier (sans dossier):"
#define SETUP_CREATEFILE_LOC		"Cr�ation du fichier"
#define SETUP_PANEERROR_LOC			"Toutes les informations demand�es sont requises."
#define SETUP_NEWPROPERTY_LOC		"Nom de la propri�t�:"
#define SETUP_NEWOPTION_LOC			"Nom de l'option:"
#define SETUP_DELETEPROPERTY_LOC	"Confirmez-vous la suppression de cette propri�t�?"
#define SETUP_DELETEOPTION_LOC		"Confirmez-vous la suppression de cet option?"
#define SETUP_OPTIONREQUIRED_LOC	"Le nom de l'option est obligatoire"
#define SETUP_DIRNOEXIST_LOC		"Le dossier de cache n'existe pas et ne peut �tre cr��."
#define SETUP_COPYERROR_LOC			"Impossible de copier les fichiers dans le dossier de cache � cause de l'erreur suivante:"

#define SETUP_DUPLICATEID_LOC		"L'ID unique sp�cifi�e existe d�j�." + CHR(10) + CHR(10) + "La valeur va �tre r�-initialis�e."
#define SETUP_NOTUNIQUE_LOC			"L'ID Unique sp�cifi�e existe d�j�."
#define SETUP_SPECIFYFILE_LOC		"Vous devez tout d'abord sp�cifier le fichier."

#define INSTALL_BADFILE_LOC			"Le fichier d'installation du centre d'information n'est pas valide."
#define INSTALL_BADVERSION_LOC		"La version du fichier d'installation du centre d'informations n'est pas correcte."
#define INSTALL_UNABLETOOPEN_LOC	"Impossible d'ouvrir les fichiers de gestion du centre d'informations."


#define PANETYPE_WEBPAGE_LOC		"Page Web"
#define PANETYPE_XML_LOC			"XML"
#define PANETYPE_HTML_LOC			"HTML"
#define PANETYPE_FOX_LOC			"Contr�les VFP"

