** Nouveaux messages d'alerte
#DEFINE UNIDENTIFIED_LIBRARY_LOC "Biblioth�que non identifi�e"
#DEFINE HISTORY_EMPTY_LOC "L'historique est vide..."

** Node Text
#DEFINE LOAD_TEXT_LOC "Chargement en cours..."

** Status text
#DEFINE TXT_READY_LOC "Pr�t."
#DEFINE TXT_LOAD_TYPELIB_LOC "Chargement de la biblioth�que de types..."
#DEFINE TXT_CLOSE_TYPELIB_LOC "Fermeture de la biblioth�que de types..."
#DEFINE TXT_LOAD_COCLASSES_LOC "Chargement des classes de composants..."
#DEFINE TXT_LOAD_CONSTANTS_LOC "Chargement des constantes..."
#DEFINE TXT_LOAD_ENUMS_LOC "Chargement des types �num�r�s..."
#DEFINE TXT_LOAD_INTERFACES_LOC "Chargement des interfaces..."
#DEFINE TXT_LOAD_EVENTS_LOC "Chargement des �v�nements..."
#DEFINE TXT_LOAD_METHODS_LOC "Chargement des m�thodes..."
#DEFINE TXT_LOAD_PROPERTIES_LOC "Chargement des propri�t�s..."
#DEFINE TXT_LOAD_DETAILS_LOC "Chargement des d�tails..."

** Tool Tips
#DEFINE TTT_OPEN_LOC "Ouvre la biblioth�que de types"
#DEFINE TTT_GO_BACK_LOC "Retour"
#DEFINE TTT_GO_BACK2_LOC "Retour vers "
#DEFINE TTT_GO_FORWARD_LOC "Aller"
#DEFINE TTT_GO_FORWARD2_LOC "Aller � "
#DEFINE TTT_REFRESH_LOC "Rafra�chir"
#DEFINE TTT_FIND_LOC "Trouver"
#DEFINE TTT_COPY_LOC "Copier"
#DEFINE TTT_HELP_LOC "Aide du Browser d'objets"
#DEFINE TTT_OPTIONS_LOC "Options du Browser d'objets"

#DEFINE TTT_TOGGLE_INTERFACES_LOC "Afficher/Masquer l'interface VTable"
#DEFINE TTT_TOGGLE_HIDDEN_LOC "Afficher/Masquer les items cach�s"
#DEFINE TTT_TOGGLE_EVENTS_LOC "Marquer toutes les sources potentielles d'�v�nements"
#DEFINE TTT_TOGGLE_DEFAULTS_LOC "Marquer les items par d�faut"
#DEFINE TTT_TOGGLE_EXPANDDETAILS_LOC "Activer/D�sactiver l'affichage complet du d�tail"

*---- TRADUCTION A FAIRE
#DEFINE TTT_TOGGLE_DRILLDOWNDETAILS_LOC "Toggle Drill Down Detail"

#DEFINE TTT_TOGGLE_INHERITEDINTERFACE_LOC "Afficher/Masquer les interfaces h�rit�es"

** Detail pane descriptions
#DEFINE DESC_CLASS_LOC "Classe"
#DEFINE DESC_MEMBER_OF_LOC "Membre de "
#DEFINE DESC_CONSTANT_LOC "Constante"
#DEFINE DESC_HEX_LOC "Hex:"
#DEFINE DESC_ENUM_LOC "Enum"
#DEFINE DESC_PROPERTY_LOC "Propri�t�"

** Other text
#DEFINE SCAN_REG_LOC "Recherche des composants dans la base de registres"
#DEFINE DISP_COMP_LOC "Mise � jour de la liste des composants..."
#DEFINE ERR_COMP_POOL_ACCESS_LOC "Impossible d'acc�der au component pool."
#DEFINE CLEAR_BROWSER_HISTORY_LOC "Etes-vous s�r de vouloir effacer l'historique du browser ?"
#DEFINE CLEAR_HISTORY_LOC "Effacer l'historique"
#DEFINE MEMBERS_OF_LOC "Membres de "
#DEFINE ITEMS_CONTAINING_LOC "Items contenant '"
#DEFINE INSTANTIATING_ADDINS_LOC "Impossible d'instancier l'AddIn " 
#DEFINE OPEN_FIRST_LOC "Vous devez d'abord ouvrir une biblioth�que."
#DEFINE REMOVE_ADDIN_LOC "Etes-vous s�rs de vouloir supprimer l'AddIn "
#DEFINE CONSISTENCY_ERROR_LOC "Erreur interne !"
#DEFINE OPERATION_ABORTED_LOC "Op�ration annul�e !"

** Menu captions
#DEFINE MNU_REMOVE_SEARCH_LOC "Supprimer la recherche"
#DEFINE MNU_CLOSE_TYPELIB_LOC "Fermer TypeLib"
#DEFINE MNU_CLEAR_CACHE_LOC "Effacer le cache"
#DEFINE MNU_CLOSE_LOC "Ouvrir"
#DEFINE MNU_FIND_LOC "Trouver"
#DEFINE MNU_NEW_WINDOW_LOC "Nouvelle fen�tre"
#DEFINE MNU_GO_BACK_LOC "En arri�re"
#DEFINE MNU_GO_FORWARD_LOC "En avant"
#DEFINE MNU_REFRESH_LOC "Rafra�chir"
#DEFINE MNU_FONT_LOC "Police"
#DEFINE MNU_ADDINS_LOC "Add-Ins..."
#DEFINE MNU_OPTIONS_LOC "Options"
#DEFINE MNU_MANUAL_INSTALL_LOC "Installation manuelle"


** Options
#DEFINE OPT_VTABLE_LOC "Afficher les interfaces VTable"
#DEFINE OPT_HIDDEN_LOC "Afficher les items cach�s"
#DEFINE OPT_EVENTS_LOC "Marquer les sources potentielles d'�v�nements"
#DEFINE OPT_DEFAULTS_LOC "Marquer les items par d�faut"
#DEFINE OPT_EXPANDDETAILS_LOC "Afficher automatiquement tout le d�tail"

*---- TRADUCTION A FAIRE
#DEFINE OPT_DRILLDOWNDETAILS_LOC "Auto Drill Down Detail"

#DEFINE OPT_INHERITEDINTERFACE_LOC "Montrer la structure d'h�ritage de l'interface"
#DEFINE OPT_IMPLEMENTINGINTERFACES_LOC "Liste de toutes les interfaces d�finissant une m�thode, un �v�nement ou une propri�t� en d�tail."
#DEFINE OPT_UNDERSCORE_LOC "Afficher les propri�t�s qui commencent par un soulign� (_)"
#DEFINE OPT_SYSTEM_LOC "Afficher les membres qui sont d�finis sur IUnknown ou IDispatch"
#DEFINE OPT_SHOWINTERFACESINDETAILS_LOC "Lister les interfaces dans le d�tail de la classe"
#DEFINE OPT_METHODPARAMETERS_LOC "Lister les param�tres de la m�thode dans le d�tail"

** Option descriptions
#DEFINE OPT_EVENTS_DESC_LOC "Indique si une source potentielle d'�v�nements (interface ou m�thode) doit �tre marqu�e comme telle."
#DEFINE OPT_DEFAULTS_DESC_LOC "Indique si oui ou non les items par d�faut doivent �tre marqu�s en utilisant le style gras de la police."
#DEFINE OPT_HIDDEN_DESC_LOC "Indique si les items cach�s doivent �tre affich�s."
#DEFINE OPT_EXPANDDETAILS_DESC_LOC "Indique si les items de premier niveau dans le panneau de d�tail doivent �tre automatiquement d�ploy�s."
#DEFINE OPT_DRILLDOWNDETAILS_DESC_LOC "Indique si les hi�rarchies complexes dans le panneau de d�tail (comme les m�thodes et propri�t�s pour chaque interface) doivent �tre automatiquement d�ploy�es."
#DEFINE OPT_VTABLE_DESC_LOC "Indique si les interfaces bas�es sur VTable et tous leurs membres doivent �tre affich�es ou non (en g�n�ral, les interfaces VTable ne sont pas vraiment importantes en Visual FoxPro)." 
#DEFINE OPT_INHERITEDINTERFACE_DESC_LOC "Indique si les interfacec h�rit�es doivent �tre affich�es dans le panneau de d�tail."
#DEFINE OPT_IMPLEMENTINGINTERFACES_DESC_LOC "Indique si toutes les interfaces d�finissant une m�thode ou une propri�t� doivent �tre list�es dans le panneau de description."
#DEFINE OPT_UNDERSCORE_DESC_LOC "Les propri�t�s qui commencent par un soulign� sont en g�n�ral des structures de type �num�ration. C'est pourquoi elles ne sont pas affich�es par d�faut."
#DEFINE OPT_SYSTEM_DESC_LOC "Tous les objets COM ont des m�thodes qui sont d�finies dans les interfaces IDispatch et IUnknown. Ces m�thodes doivent �tre l� pour fonctionner dans un environnement COM, cependant elles ne sont g�n�ralement pas utiles directement pour le d�veloppeur VFP."
#DEFINE OPT_SHOWINTERFACESINDETAILS_DESC_LOC "Toutes les classes sont bas�es sur une ou plusieurs interfaces. Souvent, les interfaces list�es dans la zone d�tail montrent simplement la m�me information que la classe enti�re, mais parfois elles fournissent plus de renseignements."
#DEFINE OPT_METHODPARAMETERS_DESC_LOC "Les param�tres d'une m�thode peuvent �tre list�s directement dans la zone de d�tail. Cependant, il faut savoir que les param�tres sont list�s avec plus de d�tail dans le panneau de description."

**********************************************
** Internal (non-localized) settings...
**********************************************

#DEFINE HKEY_CLASSES_ROOT		-2147483648  && BITSET(0,31)
#DEFINE HKEY_CURRENT_USER		-2147483647  && BITSET(0,31)+1
#DEFINE VFP_OPTIONS_KEY1		"Software\Microsoft\VisualFoxPro\"
#DEFINE VFP_OPTIONS_KEY2		"\Options\OLEList"
#DEFINE CLSID_KEY					"CLSID"
#DEFINE PROGID_KEY				"\ProgID"
#DEFINE CONTROL_KEY				"Control"
#DEFINE SERVER_KEY				"Programmable"
#DEFINE SHELL_KEY					"\Shell\"
#DEFINE INPROC_KEY				"InProcServer32"
#DEFINE LOCALSVR_KEY				"LocalServer32"

* DLL files used to read registry
#DEFINE	DLL_ADVAPI_NT		"ADVAPI32.DLL"
#DEFINE	DLL_ADVAPI_WIN95	"ADVAPI32.DLL"

* DLL files used to read ODBC info
#DEFINE DLL_ODBC_NT			"ODBC32.DLL"
#DEFINE DLL_ODBC_WIN95		"ODBC32.DLL"

* Registry roots
#DEFINE HKEY_CURRENT_USER           -2147483647  && BITSET(0,31)+1
#DEFINE HKEY_LOCAL_MACHINE          -2147483646  && BITSET(0,31)+2
#DEFINE HKEY_USERS                  -2147483645  && BITSET(0,31)+3
#DEFINE CLSID_KEY				"CLSID"
#DEFINE TYPELIB_KEY				"TYPELIB"
#DEFINE HKEY_CLASSES_ROOT		-2147483648  && BITSET(0,31)

* Misc
#DEFINE APP_PATH_KEY		"\Shell\Open\Command"
#DEFINE OLE_PATH_KEY		"\Protocol\StdFileEditing\Server"
#DEFINE VFP_OPTIONS_KEY1	"Software\Microsoft\VisualFoxPro\"
#DEFINE VFP_OPTIONS_KEY2	"\Options"
#DEFINE CURVER_KEY			"\CurVer"

* Error Codes
#DEFINE ERROR_SUCCESS		0	&& OK
#DEFINE ERROR_EOF 			259 && no more entries in key

* Data types for keys
#DEFINE REG_SZ 				1	&& Data string
#DEFINE REG_EXPAND_SZ 		2	&& Unicode string
#DEFINE REG_BINARY 			3	&& Binary data in any form.
#DEFINE REG_DWORD 			4	&& A 32-bit number.

* Data types labels
#DEFINE REG_BINARY_LOC		"*Binary*"			&& Binary data in any form.
#DEFINE REG_DWORD_LOC 		"*Dword*"			&& A 32-bit number.
#DEFINE REG_UNKNOWN_LOC		"*Unknown type*"	&& unknown type

#DEFINE APPHOOK_FILE	"APPHOOK.VCX"
#DEFINE APPHOOK_CLASS	"APPHOOK"

* Operating System codes
#DEFINE	OS_W32S				1
#DEFINE	OS_NT				2
#DEFINE	OS_WIN95			3
#DEFINE	OS_MAC				4
#DEFINE	OS_DOS				5
#DEFINE	OS_UNIX				6

* DLL Paths for various operating systems
#DEFINE DLLPATH_NT			"\SYSTEM32\"
#DEFINE DLLPATH_WIN95		"\SYSTEM\"

* DLL files used to read INI files
#DEFINE	DLL_KERNEL_NT		"KERNEL32.DLL"
#DEFINE	DLL_KERNEL_WIN95	"KERNEL32.DLL"


* ajout loc fr
#define OBROWSER_DESCEMPTY_LOC	"Vide"
