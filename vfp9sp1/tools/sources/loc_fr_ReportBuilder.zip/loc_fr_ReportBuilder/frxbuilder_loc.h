*-------------------------------------------------------
* UI control captions (not already LOC'd) :

* see a comment below with the above line
* to see how to turn on LOC'ing all interface
* elements
*-------------------------------------------------------

*=======================================================
* Report Builder localization constants
*=======================================================
* (For localization - see also: frxcursor.h)

#define c_CR	chr(13)
#define c_LF    chr(10)
#define c_CRLF  chr(13)+chr(10)
#define c_CR2	chr(13)+chr(13)
#define c_TAB	chr(9)

*-------------------------------------------------------
* Event Types
*-------------------------------------------------------

#define EVTYP_RIGHTCLICK_LOC		"Reserv�/Clic droit"
#define EVTYP_PROPERTIES_LOC		"Propri�t�s..."
#define EVTYP_OBJECT_CREATE_LOC		"Cr�er l'objet"
#define EVTYP_OBJECT_CHANGE_LOC		"Changer l'objet"
#define EVTYP_OBJECT_REMOVE_LOC		"Object Remove Supprimer l'objet"
#define EVTYP_OBJECT_PASTE_LOC		"Object Paste Coller l'objet"
#define EVTYP_REPORT_SAVE_LOC       "Report Save Sauver l'�tat"
#define EVTYP_REPORT_OPEN_LOC		"Report Open Ouvrir l'�tat"
#define EVTYP_REPORT_CLOSE_LOC		"Report Close Fermer l'�tat"
#define EVTYP_DATAENV_LOC			"Open DataEnvironment Ouvrir l'environnement de donn�es"
#define EVTYP_PRINT_PREVIEW_LOC		"Print Preview Mode Mode aper�u avant impression"
#define EVTYP_OPTIONAL_BANDS_LOC	"Optional Bands dialog Bandes optionnelles..."
#define EVTYP_DATA_GROUPING_LOC		"Data Grouping dialog Grouper les donn�es..."
#define EVTYP_VARIABLES_LOC			"Variables dialog Variables d'�tat..."
#define EVTYP_EDIT_IN_PLACE_LOC     "Edit Label Text �diter les �tiquettes"
#define EVTYP_OBJECT_DROP_LOC       "Object Drop from DE Importer un objet depuis l'environnement de donn�es"
#define EVTYP_SET_GRID_SCALE_LOC    "Set Grid Scale �chelle de la grille..."
#define EVTYP_IMPORT_DE_LOC         "Import Data Environment Importer l'environnement de donn�es"
#define EVTYP_PRINT_LOC             "Print Report Imprimer l'�tat"
#define EVTYP_QUICKREPORT_LOC       "Quick Report �tat rapide"
#define EVTYP_UNKNOWN_LOC			"�V�NEMENT INCONNU"

*-------------------------------------------------------
* Dialog Captions: 
*-------------------------------------------------------

*#define DLG_TITLE_NEW_PREFIX_LOC		"Nouveau "
#define DLG_TITLE_NEW_PREFIX_LOC		""
#define DLG_TITLE_PROPERTIES_LOC		" Propri�t�s"
#define DLG_TITLE_BAND_LOC				" Bande"
#define DLG_TITLE_READONLY_SUFFIX_LOC	" [Lecture seule]"

*-------------------------------------------------------
* Dialog context menu prompts:
*-------------------------------------------------------

#define UI_CONTEXT_EVENT_INSPECTOR_LOC   "Inspecteur d'�v�nements..."
#define UI_CONTEXT_BROWSE_FRX_LOC        "Balayage FRX..."
#define UI_CONTEXT_OPTIONS_DIALOG_LOC    "Options..."
#define UI_TOOLSMENU_OPTIONS_MESSAGE_LOC "Affiche la bo�te de dialogue par d�faut du g�n�rateur d'�tat"

*-------------------------------------------------------
* Message box strings: 
*-------------------------------------------------------

#define DEFAULT_MBOX_TITLE_LOC          	"G�n�rateur d'�tat"
#define RB_INVALID_PARAMETERS_LOC		    "Le g�n�rateur d'�tat a re�u des param�tres incorrects."
#define RB_FILE_NOT_FOUND_LOC			    "Le fichier d'�tat requis n'a pas pu �tre ouvert."

#define EVENT_INSPECTOR_TITLE_LOC           "�v�nement de Report Builder"

#define RB_GETEXPR_FAILURE_LOC              "Le handler GetExpression n'est pas disponible. INPUTBOX() le remplacera."
#define RB_DEF_GETEXPR_PROMPT_LOC           "Entrez une expression :"

#define RB_EXCEPTION_HEADER_LOC             "Le g�n�rateur d'�tat a rencontr� une erreur d'exception qu'il ne peut pas g�rer :"
#define RB_ERROR_NEWOBJECT_LOC              "Le g�n�rateur d'�tat est incapable d'instancier la classe suivante :"
#define RB_ERROR_CHECK_REGISTRY_LOC         "Assurez vous que la table de registre est correctement configur�e SVP."

#define DEVICEHELPER_ERROR_LOC			    "Impossible de lire l'information de mise en page depuis l'environnement d'impression."+ chr(13) + "Erreur : "
#define NO_PRINTERS_INSTALLED_LOC		    "Aucune imprimate install�e. Les param�tres de mise en page peuvent ne pas �tre disponibles."
#define PRINTER_INSTALLED_OK_LOC		    "Merci d'installer une imprimante. Les options de mise en page de cet �tat peuvent d�sormais �tre d�finies."

#define RUNTIME_EXT_XML_HELPER_TXT_LOC	    "�ditez directement les donn�es XML, mais conservez le format XML valide."
#define RUNTIME_EXT_NO_FRX_LOC			    "Le curseur FRX n'est pas sp�cifi� ou non disponible. les m�tadonn�es de l'�tat ne peuvent �tre �dit�es."

#define UNABLE_TO_COPY_REGISTRY_LOC         "Impossible de cr�er une copie de la table de registres."
#define OVERWRITE_EXISTING_REGISTRY_LOC     "�craser la table de registres existante?"
#define FILE_EXISTS_LOC					    "Le fichier existe:"
#define REGISTRY_TABLE_LOC				    "Table de registres:"

#define FEATURE_IS_PROTECTED_LOC		    "Fonction non disponible dans le mode prot�g� de l'�diteur d'�tats."
#define OBJECT_LOCK_LOC             	    "Cet objet ne peut �tre boug�."
#define DELETE_MBOX_TITLE_LOC			    "D�truire l'Objet"
#define DELETE_MBOX_MSG_LOC        		    "{%1} objet(s) sont prot�g�s de l'effacement."
#define OBJECT_NO_EDIT_LOC          	    "Cet objet ne peut �tre �dit�."

#define GROUPED_ITEM_PROPERTIES_LOC		    "Ces �l�ments sont group�s. Pour �diter les propri�t�s individuelles, vous devez d'abord les d�grouper par le menu Format."

#define TEXTLABEL_INVALID_CAPTION_MSG_LOC	"Vous devez donner une l�gende pour l'�tiquette."
#define FIELDEXPR_INVALID_CAPTION_MSG_LOC   "Vous devez donner une expression de champ."

#define PICTURE_INVALID_SOURCE_MSG_LOC      "Vous devez donner la source de l'image."
#define PICTURE_INVALID_FILENAME_MSG_LOC	"Impossible de localiser le fichier. Veuillez choisir une origine valide pour l'image."

#define PROPEDIT_MBOX_TITLE_LOC			    "Impossible de sauver"

#define USE_REG_ERR_MBOX_MSG_LOC		    "Impossible d'ouvrir le handler de la table de registres {%1}. La table interne par d�faut va �tre utilis�e."  

#define PRINTER_NAME_SUFFIX_DEFAULT_LOC	    " (Defaut)"

#define METADATA_DOM_CREATE_FAILED_LOC 	    "Impossible de cr�er l'instance MSXml.DomDocument. Les m�tadonn�es XML pourraient �tre indisponibles."
#define METADATA_XML_INVALID_LOC		    "Les m�tadonn�es XML pour cet �l�ment d'�tat ne sont pas valides."
#define METADATA_XML_REPLACE_LOC		    "Voulez-vous remplacer les m�tadonn�es par un fragment XML valide?"

#define BAND_REMOVE_WARNING_LOC			    "{%1} objet(s) existent dans la/les {%2} bande(s)."+c_CR+"S'ils sont conserv�s dans l'�tat, leur position dans la mise en page"+c_CR+"sera impr�visible wuand ces bandes seront d�truites."+c_CR2+"Voulez-vous d�truire ces objets quand m�me?"+c_CR2+"Oui"+c_TAB+"- Pour EFFACER les objets actuellement dans les bandes."+c_CR+"Non"+c_TAB+"- pour conserver les objets dans la mise en page."+c_CR+"Abandon"+c_TAB+"- pour revenir au dialogue pr�c�dent sans rien effacer."
#define DETAIL_BAND_REMOVE_WARN_LOC		    "{%1} objet(s) existent dans cette bande d�tail."+c_CR+"Confirmez l'effacement de la bande et de ses objets."
#define GROUP_BAND_REMOVE_WARN_LOC		    "{%1} objet(s) existent dans l'en t�te et le pied de ce groupe."+c_CR+"Confirmez l'effacement de ce groupe et des objets qu'il contient."

#define QUERY_SUSPEND_EXECUTION_LOC 	    "Voulez-vous suspendre l'ex�cution?"

#define EDIT_REPORT_VAR_PROMPT_LOC		    "Nom de Variable :"
#define EDIT_REPORT_VAR_CAPTION_LOC		    "Variable d'�tat"

#define LOAD_DE_CONFIRMATION_LOC			"Ceci va remplacer l'information pr�c�dente de l'environnement de donn�es de cet �tat. Souhaitez-vous poursuivre?"
#define LOAD_DE_ERROR_LOC					"Une erreur s'est produite lors de la tentative de lecture de la source de l'�tat."
#define LOAD_DE_INVALID_CLASS_LOC       	"Une classe de la classe de base 'DataEnvironment' doit �tre choisie."
#define LOAD_DE_ERR_INSTANTIATING_CLASS_LOC	"Une erreur s'est produite en essayant d'instancier la classe DE, et donc, ne pourra �tre li�e � l'�tat."
#define DE_METHOD_HEADER_COMMENT_LOC		"* THIS METHOD CODE WAS INSERTED BY THE REPORT BUILDER *"
#define LOAD_DE_SUCCESS_LOC					"L'environnement de donn�es de cet �tat a �t� mis � jour."

#define OTHER_EDIT_COMMENT_LOC				"Les commentaires sont enregistr�s dans le champ COMMENTS du fichier d'�tat(.frx) et ne sont pas utilis�s par le processeur d'�tats."

#define OTHER_EDIT_USER_LOC					"Les donn�es utilisateurs sont enregistr�es dans le champ USER du fichier d'�tat(.frx) et ne sont pas utilis�s par le processeur d'�tats."

#define OTHER_EDIT_TOOLTIP_LOC				"Les Tooltips sont affich�s pour les objets de mise en page dans le g�n�rateur d'�tat."

#define OTHER_EDIT_METADATA_LOC 			"Les extensions Run-time specifient des �l�ments de code accessibles aux objets ReportListener � l'ex�cution."

#define METADATA_HELPER_TEXT_LOC			"Les extensions Run-time specifient des �l�ments de code accessibles aux objets ReportListener. 'ex�cuter quand' designe une expression que les objets ReportListener peuvent �valuer pour d�cider de l'ex�cution de l'extension."

#define EDIT_SCRIPT_DLG_CAPTION_LOC			"Editer le script Runtime"
#define EDIT_META_XML_DLG_CAPTION_LOC		"Metadonn�e XML"

#define LABEL_EDIT_CAPTION_LOC              "Libell� d'�tiquette"
#define LABEL_EDIT_COMMENT_LOC				"Un libell� d'�tiquette ne peut exc�der 254 caract�res. Les caract�res au del� seront ignor�s."
#define REPORT_VAR_INVALID_NAME_LOC			"Indiquez un nom de variable valide SVP."

#define REPORT_VAR_DUPLICATE_NAME_LOC       "Indiquez un nom de variable unique SVP."

#define OPTIONS_DEFAULT_INTERNAL_LOOKUP_LOC		"table interne lookup"
#define OPTIONS_HANDLER_REGISTRY_PROMPT_LOC		"Handler de registres:"
#define OPTIONS_GETFILE_REGISTRY_TITLE_LOC		"Choix de la table de registres de gestion d'�v�nements"
#define OPTIONS_HANDLER_REGISTRY_INVALID_LOC	"La table sp�cifi�e n'existe pas ou est invalide."

#define DTL_HELPER_TEXT_LOC  					"Pendant les sessions de mise en page en mode prot�g�, les libell�s affich�s sont ceux de la conception au lieu des valeurs de champ."

#define OLEBOUND_DPI_HELPERTEXT_LOC				"Vous pouvez moduler les performances d'un report comportant des objets OLEBound en ajustant le DPI utilis� pour les restituer."

*-------------------------------------------------------
* Page Layout Preview Control:
*-------------------------------------------------------

#define PAGELAYOUT_FORM_CAPTION_LOC				"D�tails de mise en page"

#define PAGELAYOUT_INFO_PAGE_WIDTH_LOC			"Largeur Page = "
#define PAGELAYOUT_INFO_PAGE_HEIGHT_LOC			"Hauteur Page = "
#define PAGELAYOUT_INFO_ORIENTATION_LOC			"Orientation = "
#define PAGELAYOUT_INFO_UNPRINT_TOP_LOC			"Marge haute non imprimable = "
#define PAGELAYOUT_INFO_UNPRINT_LEFT_LOC		"Marge gauche non imprimable = "
#define PAGELAYOUT_INFO_EXTRA_LEFT_LOC			"Marge gauche additionnelle = "
#define PAGELAYOUT_INFO_COL_COUNT_LOC			"Nbre de colonnes = "	
#define PAGELAYOUT_INFO_COL_WIDTH_LOC			"Largeur Colonne = "
#define PAGELAYOUT_INFO_COL_SPACE_LOC			"Goutti�re = "
#define PAGELAYOUT_INFO_HEADER_SIZE_LOC			"Taille d'ent�te = "
#define PAGELAYOUT_INFO_FOOTER_SIZE_LOC			"Taille de pied = "

*-------------------------------------------------------
* Calculation combo list:
*-------------------------------------------------------

#define CALCULATE_NOTHING_LOC	    "Rien"
#define CALCULATE_COUNT_LOC		    "Compter"
#define CALCULATE_SUM_LOC		    "Sommer"
#define CALCULATE_AVERAGE_LOC	    "Moyenne"
#define CALCULATE_LOWEST_LOC	    "Minimum"
#define CALCULATE_HIGHEST_LOC	    "Maximum"
#define CALCULATE_STDDEV_LOC	    "D�viation Standard"
#define CALCULATE_VARIANCE_LOC	    "Variance"

#define PICTUREMODE_CLIP_LOC                "Tronquer le contenu"
#define PICTUREMODE_SCALE_KEEP_SHAPE_LOC    "Isom�trique"
#define PICTUREMODE_SCALE_STRETCH_LOC       "Extension"

*-------------------------------------------------------
* Line/Shape Styles:
*-------------------------------------------------------

#define LINE_STYLE_0_LOC			"Aucun"
#define LINE_STYLE_1_LOC			"Points"
#define LINE_STYLE_2_LOC			"Traits"
#define LINE_STYLE_3_LOC			"Trait-point"
#define LINE_STYLE_4_LOC			"Trait-point-point"
#define LINE_STYLE_5_LOC			"Pointill�"
#define LINE_STYLE_6_LOC			"Petits points"
#define LINE_STYLE_7_LOC			"Gros Points"
#define LINE_STYLE_8_LOC			"Normal"

#define LINE_WIDTH_HAIRLINE_LOC		"Trait fin"
#define LINE_WIDTH_1POINT_LOC		"1 point (normal)"
#define LINE_WIDTH_2POINT_LOC		"2 point"
#define LINE_WIDTH_4POINT_LOC		"4 point"
#define LINE_WIDTH_6POINT_LOC		"6 point"

*-------------------------------------------------------
* Measurement units (option/combo values):
*-------------------------------------------------------

#define UNITS_NORULER_LOC	 	"Pouces (sans r�gles)"
#define UNITS_INCHES_LOC	 	"Pouces"
#define UNITS_METRIC_LOC	 	"Metrique/cm"
#define UNITS_PIXELS_LOC	 	"Pixels"
#define UNITS_NONPAREIL_LOC  	"Unit�s non identiques"
#define UNITS_CHARACTERS_LOC 	"Caract�res"

*-------------------------------------------------------
* String Trimming Modes (option/combo values):
*-------------------------------------------------------

#define STRINGTRIM_DEFAULT_LOC          "Rognage par d�faut"
#define STRINGTRIM_CHAR_LOC             "Couper au plus proche carat�re"
#define STRINGTRIM_WORD_LOC             "Couper au plus proche mot"
#define STRINGTRIM_ELLIPSIS_CHAR_LOC    "Couper au plus proche carat�re, ajouter points de suspension"
#define STRINGTRIM_ELLIPSIS_WORD_LOC    "Couper au plus proche mot, ajouter points de suspension"
#define STRINGTRIM_ELLIPSIS_FILE_LOC    "Nom de fichiers: Raccourcir la chemin interne en points de suspension"

*-------------------------------------------------------
* UI control captions (not already LOC'd) :
*-------------------------------------------------------

#define USE_LOC_STRINGS_IN_UI				.T.    && Set this .T. to enable these LOC strings in UI controls

*-------------------------------------------------------
* Use code like this in the object's .Init():
*
*#IF USE_LOC_STRINGS_IN_UI
*    THIS.Caption = UI_CMD_OK_LOC
*#ENDIF
*
*-------------------------------------------------------

#define UI_CMD_OK_LOC						"OK"
#define UI_CMD_CANCEL_LOC					"Abandon"
#define UI_CMD_HELP_LOC 					"Aide"

#define UI_CMD_FONT_LOC						"Police..."
#define UI_CMD_CLOSE_LOC					"Fermer"
#define UI_CMD_ADD_RECORD_LOC				"Ajout d'enregistrement"

#define UI_CMD_ADD_LOC						"Ajouter"
#define UI_CMD_REMOVE_LOC					"Enlever"

*--- Tab Captions:

#define UI_TAB_GENERAL_LOC				"General"	
#define UI_TAB_BAND_LOC					"Bande"
#define UI_TAB_STYLE_LOC				"Style"
#define UI_TAB_FORMAT_LOC				"Format"
#define UI_TAB_PRINTWHEN_LOC			"Imprimer lorsque..."
#define UI_TAB_CALCULATE_LOC			"Calculer"
#define UI_TAB_OTHER_LOC				"Autre"
#define UI_TAB_PAGELAYOUT_LOC			"Mise en page"
#define UI_TAB_OPTIONALBANDS_LOC		"Bandes Optionnelles"
#define UI_TAB_DATAGROUP_LOC			"Groupement de donn�es"
#define UI_TAB_VARIABLES_LOC			"Variables"
#define UI_TAB_PROTECTION_LOC			"Protection"
#define UI_TAB_RULERGRID_LOC			"R�gles/Grille"
#define UI_TAB_DATAENV_LOC				"Environnement de donn�es"

#define UI_TAB_SELECTION_LOC			"Selection"
#define UI_TAB_PROPERTIES_LOC			"Propri�t�s"

*--- Options dialog:

#define UI_OPTIONS_FORM_CAPTION_LOC         "Options du g�n�rateur d'�tat"

#define UI_OPTIONS_LBL_EVENT_HANDLING_LOC	" Designer d'�tat event handling "
#define UI_OPTIONS_LBL_HANDLE_TEXT_LOC      "En g�rant les �v�nements du Report Designer, le g�n�rateur ...:"
#define UI_OPTIONS_LBL_HANDLER_TABLE_LOC    " Table Handler Registry "
#define UI_OPTIONS_LBL_TABLE_TEXT_LOC       "Le g�n�rateur d'�tat utilise une table pour d�terminer quelle classe utiliser pour g�rer un ev�nement et/ou un type d'objet du g�n�rateur."
#define UI_OPTIONS_LBL_COPY_TEXT_LOC        "Si vous souhaitez �craser la correspondance par d�faut des classes de gestion d'�v�nements, vous devrez cr�er une copis modifiable de la table interne de gestion."
#define UI_OPTIONS_LBL_EXPLORE_TEXT_LOC     "Registry Explorer provides a way for you to browse the current handler registry table, and make changes if you have appropriate permissions."

#define UI_OPTIONS_CMD_COPY_LOC				"\<Cr�er une copie"
#define UI_OPTIONS_CMD_EXPLORE_LOC			"Registry \<Explorateur"

#define UI_OPTIONS_OPT_SEARCH_LOC           "Chercher une classe \<handler dans la table de registres (voir ci dessous)"
#define UI_OPTIONS_OPT_DEBUG_LOC            "Utiliser le \<debug handler pour tous les �v�nements"
#define UI_OPTIONS_OPT_INSPECT_LOC          "Utiliser l'inspecteur d'�\<venement pour tous les �v�nements"
#define UI_OPTIONS_OPT_IGNORE_LOC           "\<Ignorer compl�tement les �v�nements du g�n�rateur"
#define UI_OPTIONS_OPT_USE_INTERNAL_LOC     "\<Utiliser la table interne"
#define UI_OPTIONS_OPT_USE_ALTERNATE_LOC    "U\<tiliser la table alternative:"

*--- Registry Explorer dialog:

#define UI_REGEXPLR_FORM_CAPTION_LOC		"Event Handler Registry"
#define UI_REGEXPLR_COL_TYPE_LOC			"Type"
#define UI_REGEXPLR_COL_CLASS_LOC			"Classe"
#define UI_REGEXPLR_COL_LIBRARY_LOC			"Biblioth�que"
#define UI_REGEXPLR_COL_DESCRIPT_LOC		"Description"
#define UI_REGEXPLR_COL_EVENT_LOC			"Ev�nementt"
#define UI_REGEXPLR_COL_OBJTYP_LOC			"Objtype"
#define UI_REGEXPLR_COL_OBJCOD_LOC			"Objcode"
#define UI_REGEXPLR_COL_NATIVE_LOC			"Native"
#define UI_REGEXPLR_COL_DEBUG_LOC			"Debug"
#define UI_REGEXPLR_COL_FILTER_LOC			"Filter order"

*--- Metadata Editor dialog:

#define UI_CMD_EDIT_XML_LOC					"Editer XML..."
#define UI_METAEDIT_LBL_RTEXTENSION_LOC		"Extensions Run-time:"
#define UI_METAEDIT_LBL_EXECWHEN_LOC		"Executer quand:"

*--- FRX Browser dialog:

#define UI_FRXBROWS_FORM_CAPTION_LOC		"Balayage de table FRX"

*--- Multiple selection dialog:

#define UI_MULTISEL_APPLY_PROTECTION_LOC	"Appliquer ces valeurs de protection aux objets s�lectionn�s:"
#define UI_MULTISEL_APPLY_PRINTWHEN_LOC		"Appliquer ces conditions aux objets s�lectionn�s � la sauvegarde:"

*--- FRX Browse Panel:

#define UI_FRXBROWS_CHK_CURPOS_LOC			"CURPOS=.T. (Objet selectionn� dans la mise en page)"

*--- Object Position Panel:

#define UI_OBJPOS_LBL_OBJECT_POS_LOC		" Position de l'Objet "
#define UI_OBJPOS_OPT_FLOAT_LOC				"\<Flottant"
#define UI_OBJPOS_OPT_FIX_REL_TO_TOP_LOC    "Fix� par rapport au hau\<t de la bande"
#define UI_OBJPOS_OPT_FRX_REL_TO_BOTTOM_LOC "Fix� par rapport au \<bas de la bande"

*--- Stretch Down Panel:

#define UI_STRETCH_LBL_STRETCH_LOC			" �tirer vers la bas "
#define UI_STRETCH_OPT_NO_STRETCH_LOC		"\<Ne pas �tirer"
#define UI_STRETCH_OPT_REL_TO_TALLEST_LOC   "Ajuster au p\<lus grand objet dans le groupe"
#define UI_STRETCH_OPT_REL_TO_HEIGHT_LOC    "�tirer sur la \<hauteur de la bande"

*--- Absolute Positioning panel:

#define UI_ABSPOS_LBL_CAPTION_LOC			" Taille et Position dans la page "
#define UI_ABSPOS_LBL_PAGE_TOP_LOC			"Du haut de page:"
#define UI_ABSPOS_LBL_LEFT_LOC				"De la gauche:"
#define UI_ABSPOS_LBL_HEIGHT_LOC			"Hauteur:"
#define UI_ABSPOS_LBL_WIDTH_LOC				"Largeur:"

*--- Band panel:

#define UI_BAND_LBL_HEIGHT_LOC				"\<Hauteur:"
#define UI_BAND_CHK_CONSTANT_HEIGHT_LOC		"Bande de hauteur constante"
#define UI_BAND_LBL_RUN_EXPR_LOC			" Ex�cuter l'expression "
#define UI_BAND_LBL_ONENTRY_LOC				"� l'\<entr�e:"
#define UI_BAND_LBL_ONEXIT_LOC				"� la sortie:"

*--- Band protection panel:

#define UI_BANDPROT_LBL_CAPTION_LOC			" En mode PROT�G� "
#define UI_BANDPROT_LBL_HELP_TEXT_LOC		"Les restrictions suivantes s'appliqueront � cette bande quand la mise en page est modifi�e an mode prot�g�:"
#define UI_BANDPROT_CHK_NO_RESIZE_LOC		"La bande ne peut �tre redimensionn�e"
#define UI_BANDPROT_CHK_NO_PROPS_LOC		"La bo�te de dialogue des prori�t�s n'est pas disponible"

*--- Calculate panel:

#define UI_CALCULATE_LBL_CAPTION_LOC		" Calculer "
#define UI_CALCULATE_LBL_TYPE_LOC			"Type de calcul:"
#define UI_CALCULATE_LBL_RESET_LOC			"R�initialisation sur:"

*--- Comment/User panel:

#define UI_COMMENTUSER_LBL_COMMENT_LOC		"Commentaire "
#define UI_COMMENTUSER_LBL_USERDATA_LOC		"Donn�es utilisateur "
#define UI_COMMENTUSER_CMD_EDIT_COMMENT_LOC "Editer le commentaire..."
#define UI_COMMENTUSER_CMD_EDIT_USER_LOC    "Editer les Donn�es utilisateur..."

*--- Load DE panel:

#define UI_LOADDE_LBL_CAPTION_LOC			" Charger l'environnement de donn�es "
#define UI_LOADDE_OPT_COPY_FROM_FRX_LOC		"Copier depuis un autre fichier d'�tat"
#define UI_LOADDE_OPT_LINK_TO_CLASS_LOC		"Lier � une classe d'environnement de donn�es"
#define UI_LOADDE_CMD_SELECT_LOC			"Choisir..."
#define UI_LOADDE_LBL_CLASSNAME_LOC			"Classe:"
#define UI_LOADDE_LBL_LIBRARY_LOC			"Class Library / Source:"
#define UI_LOADDE_CHK_PRIVATE_SESSION_LOC	"L'�tat utilise une session de donn�es priv�e"

*--- DesignTime Label panel:

#define UI_DTLABEL_LBL_CAPTION_LOC			"Titre � la cr�ation:"

*--- Detail band properties panel:

#define UI_DETAIL_LBL_CAPTION_LOC			" Propri�t�s "
#define UI_DETAIL_CHK_NEW_COLUMN_LOC		"D�part sur une nouvelle \<colonne"
#define UI_DETAIL_CHK_NEW_PAGE_LOC			"d�part sur une nouvelle \<page"
#define UI_DETAIL_CHK_RESET_PAGE_LOC		"R�initialiser le \<num�ro de page � 1 pour chaque jeu de d�tail"
#define UI_DETAIL_CHK_HEADERFOOTER_LOC      "En-t�te et pied de bande associ�s"
#define UI_DETAIL_CHK_REPRINT_HEADER_LOC	"\<R�imprimer l'ent�te du d�tail sur chaque page"
#define UI_DETAIL_LBL_THRESHOLD_LOC			"\<D�marrer le jeu de d�tail sur une nouvelle page quand il reste moins de:"
#define UI_DETAIL_LBL_TARGET_ALIAS_LOC		"alias de la cible:"

*--- Detail bands panel:

#define UI_DETAILBANDS_LBL_CAPTION_LOC		" Bandes d�tail"

*--- Field Expression panel:

#define UI_FIELDEXPR_LBL_CAPTION_LOC		"\<Expression:"

*--- Field Format panel:

#define UI_FORMAT_LBL_CAPTION_LOC			"Expression de \<format:"
#define UI_FORMAT_OPT_CHARACTER_LOC			"\<Carat�re"
#define UI_FORMAT_OPT_NUMERIC_LOC			"\<Numerique"
#define UI_FORMAT_OPT_DATE_LOC				"\<Date"
#define UI_FORMAT_LBL_OPTIONS_LOC			" Options de format "

#define UI_FORMAT_LBL_TEMPLATE_LOC			"Template characters"
#define UI_FORMAT_OPT_OVERLAY_LOC			"\<Superposer"
#define UI_FORMAT_OPT_INTERLEAVE_LOC		"\<Entrelacer"
#define UI_FORMAT_LBL_JUSTIFY_LOC			"Justification"
#define UI_FORMAT_OPT_JUST_LEFT_LOC			"\<Gauche"
#define UI_FORMAT_OPT_JUST_RIGHT_LOC		"\<Droite"
#define UI_FORMAT_OPT_JUST_CENTER_LOC		"Cen\<trer"
#define UI_FORMAT_CHK_UPPERCASE_LOC			"\<Majuscules"
#define UI_FORMAT_CHK_SET_DATE_LOC			"Format \<SET DATE"
#define UI_FORMAT_CHK_BRITISH_DATE_LOC		"\<British date"

#define UI_FORMAT_CHK_LEFT_JUST_LOC			"Justifier � \<Gauche"
#define UI_FORMAT_CHK_ZERO_BLANK_LOC		"Blanc si \<zero"
#define UI_FORMAT_CHK_NEGATIVE_LOC			"(N�\<gatif)"
#define UI_FORMAT_CHK_CR_POSITIVE_LOC		"C\<R si positif"
#define UI_FORMAT_CHK_DB_NEGATIVE_LOC		"DB si n�gati\<f"
#define UI_FORMAT_CHK_LEADING_0_LOC			"\<z�ros de t�te"
#define UI_FORMAT_CHK_CURRENCY_LOC			"M\<on�taire"
#define UI_FORMAT_CHK_SCIENTIFIC_LOC		"Scien\<tifique"

#define UI_FORMAT_CHK_BLANK_EMPTY_LOC		"Blanc si \<vide"

#define UI_FORMAT_LBL_TRIM_MODE_LOC			"\<Mode de troncature pour les expressions caract�res:"

*--- Field Positioning panel:

#define UI_FIELDPOS_CHK_OVERFLOW_LOC		"\<�tirer si d�bordement"

*--- Group Expression panel:

#define UI_GROUPEXPR_LBL_CAPTION_LOC		"\<Expression de regroupement:"

*--- Grouping panel:

#define UI_GROUPING_LBL_NESTING_LOC			"Ordre de regroupement imbriqu�:"
#define UI_GROUPING_LBL_GROUP_ON_LOC		"Grouper sur:"
#define UI_GROUPING_LBL_STARTS_ON_LOC		" Le Groupe d�marre sur "
#define UI_GROUPING_OPT_NEW_LINE_LOC		"Nouvelle ligne"
#define UI_GROUPING_OPT_NEW_COL_LOC			"Nouvelle \<colonne"
#define UI_GROUPING_OPT_NEW_PAGE_LOC		"Nouvelle \<page"
#define UI_GROUPING_OPT_NEW_PAGE1_LOC		"\<Nouvelle page num�ro 1"
#define UI_GROUPING_CHK_REPRINT_LOC			"\<R�imprimer l'ent�te de groupe sur chaque page"
#define UI_GROUPING_LBL_THRESHOLD_LOC		"\<D�marrer le groupe sur une nouvelle page s'il reste moins de:"

*--- Member data panel:

#define UI_MEMBERDATA_LBL_CAPTION_LOC		"Extensions Run-time "
#define UI_MEMBERDATA_CMD_EDIT_LOC			"Edit settings..."

*--- MultiPrint When panel:

#define UI_MULTIPRINTWHEN_LBL_CAPTION_LOC	"Im\<primer seulement si l'expression est vraie:"

*--- MultiSelect panel:

#define UI_MULTISELECT_LBL_OBJECT_LOC		"\<Objet"
#define UI_MULTISELECT_LBL_BAND_LOC			"Band de d�part"
#define UI_MULTISELECT_LBL_SORT_BY_LOC		" Trier par "
#define UI_MULTISELECT_OPT_TYPE_LOC			"\<Type"
#define UI_MULTISELECT_OPT_LOCATION_LOC		"\<Endroit"
#define UI_MULTISELECT_CMD_REMOVE_LOC		"Enlever de la liste"

*--- Object Protection panel:

#define UI_OBJPROTECT_LBL_CAPTION_LOC		" En mode PROT�G� "
#define UI_OBJPROTECT_LBL_TEXT_LOC			"Les restrictions suivantes s'appliqueront � ce contr�le quand la mise en page est modifi�e en mode prot�g�:"
#define UI_OBJPROTECT_CHK_NO_RESIZE_LOC		"L'objet ne peut �tre d�plac� ou redi\<mensionn�"
#define UI_OBJPROTECT_CHK_NO_PROPS_LOC		"\<La bo�te de dialogue des propri�t�s n'est pas disponible"
#define UI_OBJPROTECT_CHK_NO_DELETE_LOC		"L'objet ne peut �tre \<d�truit"
#define UI_OBJPROTECT_CHK_NO_SELECT_LOC		"L'object ne peut �tre \<s�lectionn�"
#define UI_OBJPROTECT_CHK_NOT_VISIBLE_LOC	"L'object est in\<visible dans le Designer"

*--- Optional Bands panel:

#define UI_OPTBANDS_LBL_TITLE_LOC			" Titre "
#define UI_OPTBANDS_CHK_TITLE_LOC			"L'�tat a une bande \<Titre"
#define UI_OPTBANDS_CHK_TITLE_NEW_PAGE_LOC	"Une \<nouvelle page est imprim�e apr�s le titre"
#define UI_OPTBANDS_LBL_SUMMARY_LOC			" R�sum� "
#define UI_OPTBANDS_CHK_SUMMARY_LOC			"L'�tat a une bande de r�su\<m�"
#define UI_OPTBANDS_CHK_SUMM_NEW_PAGE_LOC	"Le r�sum� s'imprime sur une nouvelle \<page"
#define UI_OPTBANDS_CHK_SUMM_HEADER_LOC		"Ajouter l'ent�te de page au \<r�sum�"
#define UI_OPTBANDS_CHK_SUMM_FOOTER_LOC		"Ajouter le pied de pa\<ge au r�sum�"

*--- Page Layout panel:

#define UI_PAGELAYOUT_LBL_COLUMNS_LOC		" Colonnes "
#define UI_PAGELAYOUT_LBL_NUMBER_LOC		"Nombrer:"
#define UI_PAGELAYOUT_LBL_WIDTH_LOC			"Largeur:"
#define UI_PAGELAYOUT_LBL_SPACING_LOC		"Goutti�re:"
#define UI_PAGELAYOUT_LBL_MARGIN_LOC		"Marge gauche:"

#define UI_PAGELAYOUT_LBL_PRINT_AREA_LOC	" Zone imprimable "
#define UI_PAGELAYOUT_OPT_PRINTABLE_LOC		"Page imprimable"
#define UI_PAGELAYOUT_OPT_WHOLE_LOC			"Page enti�ree"

#define UI_PAGELAYOUT_LBL_PRINT_ORDER_LOC	" Sens d'impression des colonnes "
#define UI_PAGELAYOUT_OPT_TOP_BOTTOM_LOC	"de haut en bas"
#define UI_PAGELAYOUT_OPT_LEFT_RIGHT_LOC	"de gauche � droite"

#define UI_PAGELAYOUT_LBL_DEF_FONT_LOC		" Police par d�faut "
#define UI_PAGELAYOUT_CHK_FONTSCRIPT_LOC	"Utiliser le script pour la police"

#define UI_PAGELAYOUT_LBL_PRINTER_LOC		" Imprimante "
#define UI_PAGELAYOUT_CMD_PAGE_SETUP_LOC	"Page Setup..."
#define UI_PAGELAYOUT_CHK_SAVE_ENV_LOC		"Sauver l'environnement d'impression"

*--- Picture/Bound panel:

#define UI_PICTBOUND_LBL_CAPTION_LOC		" Type de source du contr�le "
#define UI_PICTBOUND_OPT_FILE_LOC			"Nom de fichier Image"
#define UI_PICTBOUND_OPT_GENERAL_LOC		"Nom de champ General"
#define UI_PICTBOUND_OPT_EXPRVAR_LOC		"Expression ou nom de variable"
#define UI_PICTBOUND_LBL_SOURCE_LOC			"Source du contr�le:"
#define UI_PICTBOUND_LBL_PICTMODE_LOC		"Si la source et le cadre sont de tailles diff�rentes:"
#define UI_PICTBOUND_CHK_CENTER_LOC			"Centrer le champ general horizontalement dans le cadre"

*--- Print When panel:

#define UI_PRINTWHEN_LBL_CAPTION_LOC		" Imprimer les valeurs r�p�t�es "
#define UI_PRINTWHEN_OPT_YES_LOC			"\<Oui"
#define UI_PRINTWHEN_OPT_NO_LOC				"\<Non"
#define UI_PRINTWHEN_LBL_ALSO_PRINT_LOC		" Imprimer aussi "
#define UI_PRINTWHEN_CHK_FIRST_WHOLE_LOC	"Dans la \<premi�re bande enti�re d'une nouvelle page/colonne"
#define UI_PRINTWHEN_CHK_EXPR_CHANGE_LOC	"Quand cette expression de \<regroupement de donn�es change:"
#define UI_PRINTWHEN_CHK_OVERFLOW_LOC		"Quand le contenu de la \<bande d�borde sur une nouvelle page/colonne"
#define UI_PRINTWHEN_CHK_REMOVE_BLANK_LOC	"\<Supprimer les lignes vides"
#define UI_PRINTWHEN_LBL_PRINT_EXPR_LOC		"\<Imprimer seulement si l'expression est vraie:"

*--- Report Protection panel:

#define UI_REPPROTECT_LBL_CAPTION_LOC		" En mode PROT�G� "
#define UI_REPPROTECT_LBL_TEXT_LOC			"Selectionnez les �l�ments qui seront indisponibles quand la mise en page sera modifi�e en mode prot�g�:"
#define UI_REPPROTECT_CHK_NO_PRINT_LOC		"L'�tat ne peut pas �tre ex�cut� ou im\<prim�"
#define UI_REPPROTECT_CHK_NO_PREVIEW_LOC	"L'�tat ne peut pas �tre pr�\<visualis�"
#define UI_REPPROTECT_CHK_NO_DATAENV_LOC	"L'environnement de donn�es n'est pas disponible"
#define UI_REPPROTECT_CHK_NO_PAGELAYOUT_LOC "\<La mise en page n'est pas disponible"
#define UI_REPPROTECT_CHK_NO_OPTBANDS_LOC	"Les bandes \<Optionnelles ne peuvent �tre chang�es"
#define UI_REPPROTECT_CHK_NO_GROUPING_LOC	"Les re\<groupements de donn�es ne peuvent �tre modifi�s"
#define UI_REPPROTECT_CHK_NO_REPVARS_LOC	"Les \<variables d'�tat ne peuvent �tre �dit�es"

*--- Ruler/Grid panel:

#define UI_RULERGRID_LBL_RULER_LOC			" R�gles "
#define UI_RULERGRID_LBL_UNITS_LOC			"Unit�s:"
#define UI_RULERGRID_CHK_SHOW_POSITION_LOC	"Afficher la position dans la barre de status"
#define UI_RULERGRID_LBL_GRID_LOC			" Grille "
#define UI_RULERGRID_CHK_SHOW_GRID_LOC		"Afficher la grille"
#define UI_RULERGRID_CHK_SNAP_TO_GRID_LOC	"Aligner sur la grille"
#define UI_RULERGRID_LBL_HORIZONTAL_LOC		"Espacement horizontal:"
#define UI_RULERGRID_LBL_VERTICAL_LOC		"Espacement vertical:"

*--- Report Variables panel:

#define UI_REPVARS_LBL_CAPTION_LOC			"Variables:"
#define UI_REPVARS_LBL_STORE_VALUE_LOC		"Valeur � enregistrer:"
#define UI_REPVARS_LBL_INITIAL_LOC			"Valeur initiale:"
#define UI_REPVARS_LBL_RESET_ON_LOC			"R�initialisser si:"
#define UI_REPVARS_LBL_CALC_TYPE_LOC		"Type de calcul:"
#define UI_REPVARS_CHK_RELEASE_LOC			"Supprimer en fin d'�tat"

*--- Shape format panel:
*--- Text format panel:

#define UI_SHAPE_LBL_STYLE_LOC				"Style:"
#define UI_SHAPE_LBL_WEIGHT_LOC				"�paisseur:"
#define UI_SHAPE_LBL_CURVATURE_LOC			"Courbure:"
#define UI_SHAPE_LBL_COLOR_LOC				" Couleur "

#define UI_TEXTFORMAT_LBL_FONT_LOC			" Police "
#define UI_TEXTFORMAT_CHK_FONTSCRIPT_LOC	"Utilser le script de police"
#define UI_TEXTFORMAT_CHK_STRIKETHRU_LOC	"Barr�"
#define UI_TEXTFORMAT_CHK_UNDERLINE_LOC		"Soulign�"

#define UI_FORMAT_CHK_FORECOLOR_LOC			"Utiliser la couleur de premier plan par d�faut(pen)"
#define UI_FORMAT_CHK_BACKCOLOR_LOC			"Utiliser la couleur d'arri�re plan par d�faut(fill)"
#define UI_FORMAT_LBL_BACKSTYLE_LOC			" Style d'arri�re plan "
#define UI_FORMAT_OPT_OPAQUE_LOC			"Opaque"
#define UI_FORMAT_OPT_TRANSPARENT_LOC		"Transparent"
#define UI_FORMAT_LBL_SAMPLE_LOC			" Exemple "

*--- Text Label panel:

#define UI_TEXTLABEL_LBL_CAPTION_LOC		"Intitul�:"

*--- Tooltip panel:

#define UI_TOOLTIP_LBL_CAPTION_LOC			"Tooltip "
#define UI_TOOLTIP_CMD_EDIT_LOC				"Editer le tooltip..."

