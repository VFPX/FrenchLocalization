* FR_LOC_FOXREFFIND.H 
* francisation compl�mentaire du foxreffind.scx
*
* pr�fixe B pour buttons
* pr�fixe L pour les labels
* pr�fixe K pour les chekbox
*
* xxx0_LOC pour le caption
* xxx1_LOC pour le statusbartext
* xxx2_LOC pour le tooltiptext

#DEFINE FR_FIND0_LOC 			"Recherche" 

#DEFINE B_FR_SEARCH0_LOC 		"\<Rechercher"
#DEFINE B_FR_CANCEL0_LOC 		"Annuler"
#DEFINE B_FR_REGEXPRMENU2_LOC 	"Aide sur les expressions conformes"
#DEFINE L_FR_LOOKFOR0 			"Cherc\<her"
#DEFINE L_FR_SCOPE0 			"Eten\<due"
#DEFINE L_FR_LOOKIN0 			"\<O� ?"
#DEFINE L_FR_FILETYPES0 		"\<Types :"
#DEFINE L_FR_COMMENTS0 			"Co\<mmentaires"
#DEFINE K_FR_MATCHCASE0 		"Respecter la \<casse"
#DEFINE K_FR_WHOLEWORDS0 		"Mots \<Entiers"
#DEFINE K_FR_SUBFOLDERS0 		"\<Sous-dossiers"
#DEFINE K_FR_OVERWRITE0 		"\<Ecraser les r�sultats pr�c�dents"
#DEFINE K_FR_WILDCARDS0 		"E\<xpressions conformes"
#DEFINE K_FR_PROJECTHOMEDIR0 	"\<Limiter la recherche au dossier du projet et � ses sous-dossiers"

