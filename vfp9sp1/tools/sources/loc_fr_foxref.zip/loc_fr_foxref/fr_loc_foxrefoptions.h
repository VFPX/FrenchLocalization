* FR_LOC_FOXREFOPTIONS.H 
* francisation compl�mentaire du foxrefoptions.scx
*
* pr�fixe B pour buttons
* pr�fixe L pour les labels
* pr�fixe K pour les chekbox
*
* xxx0_LOC pour le caption
* xxx1_LOC pour le statusbartext
* xxx2_LOC pour le tooltiptext

#DEFINE B_FR_OPTFONT0 		"\<Police"
#DEFINE B_FR_OPTCLEAN0		"\<Nettoyer les tables sources"

#DEFINE O_FR_OPTBACKUP10	"NomFichier.ext.bak"
#DEFINE O_FR_OPTBACKUP20	"Copie de NomFichier.ext"

#DEFINE L_FR_BACKUPSTYLE	"Type de sauvegarde"
#DEFINE L_FR_DIRECTORY		"Dossier des tables de r�f�rences de code"