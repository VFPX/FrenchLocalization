* Program....: FOXREF.H
* Date.......: February 26, 2002
* Abstract...: Header file for Source Reference application
* Changes....:
* Localisation..: Gilles Patrick pgilles@ikoonet.com
* Date .........: 19/04/2005
* R�vis� par ...: Michel L�vy michelvfplevy@yahoo.fr
* Le............: 20/04/2005

#INCLUDE "fr_loc_foxreffind.h"
#INCLUDE "fr_loc_foxrefreplace.h"
#INCLUDE "fr_loc_foxrefprint.h"
#INCLUDE "fr_loc_foxrefoptions.h"

#define TAB					CHR(9)

* possible actions for starting FoxRef (see foxrefstart.prg)
#define MODE_REFERENCES		0
#define MODE_GOTODEF		1
#define MODE_LOOKUP			2

* this is what ProjectFile property is set to if we're searching folders
* rather than a specific Project
#define PROJECT_GLOBAL		"REF_GLOBAL"


* extension to append to Project Name
* when naming the reference table 
* If Project is called VisGift.PJX, then 
* reference table is called VisGift_ref.dbf
#define RESULT_EXT			"_ref"

* RESULT_EXT is append to this to become global_ref.dbf
#define GLOBAL_TABLE		"global"

#define FILE_TABLE			"RefFile"
#define DEF_TABLE			"RefDef"
#define ADDIN_TABLE			"RefAddIn"

* default report filename
#define REPORT_FILE			"foxrefresults.frx"

#define FONT_DEFAULT		"Tahoma,8,N"

#define TABLEFIND_ALIAS		"TableFind"
#define WORD_DELIMITERS		" ,.&()=[]'" + ["] + CHR(9)
#define METHOD_DELIMITERS	" ,&()=[]'" + ["] + CHR(9)


#define DEFINITION_DELIMITERS	" ,()" + CHR(9)

#define MAX_TOKENS			100

* The following are invalid in an alias name so we replace with '_'
#define INVALID_ALIAS_CHARS	" .-@#$%^&*()+={}[]:;?/<>,\|~`'" + ["]

* max number of characters a code line can be in 
* a grid before we cut it off
#define MAX_LINE_LENGTH		254

* these are the Types defined in RefAddIn Table
#define ADDINTYPE_FINDFILE		"FINDFILE"
#define ADDINTYPE_IGNOREFILE	"IGNOREFILE"
#define ADDINTYPE_FINDWINDOW	"FINDWINDOW"
#define ADDINTYPE_REPORT		"REPORT"
#define ADDINTYPE_MATCH			"MATCH"
#define ADDINTYPE_WILDMATCH		"WILDMATCH"
#define ADDINTYPE_FILETYPE		"FILETYPE"


* default file types if none specified in history (Common Source)
#define FILETYPES_DEFAULT	  "*.scx;*.vcx;*.prg;*.frx;*.lbx;*.mnx;*.dbc;*.qpr;*.h"
#define FILETYPES_DEFINITIONS "*.scx;*.vcx;*.prg;*.h;*.dbc;*.frx;*.lbx;*.mpr;*.spr;*.qpr"

* default search engines and their class libraries
#define FILETYPE_CLASS_DEFAULT		"RefSearch"
#define FILETYPE_LIBRARY_DEFAULT	"FoxRefSearch.prg"



* references into aFileTypes array
#define FILETYPE_EXTENSION	1
#define FILETYPE_ENGINE		2


* for nSearchType parameter in SearchText() method
#define SEARCHTYPE_NORMAL		0
#define SEARCHTYPE_METHOD		1
#define SEARCHTYPE_EXPR			2
#define SEARCHTYPE_TEXT			3


#DEFINE EDENV_FILENAME      1
#DEFINE EDENV_LENGTH		2
#DEFINE EDENV_READONLY		12
#DEFINE EDENV_SELSTART		17
#DEFINE EDENV_SELEND		18

#define SCOPE_PROJECT		'P'
#define SCOPE_FOLDER		'D'
#define SCOPE_FILE			'F'
#define SCOPE_CLASS			'C'

* Resource File ID
#define RESOURCE_ID			"FOXREF"

* File Types, as used by FoxRef.FileAction
#define FILEACTION_NODEFINITIONS	'N'
#define FILEACTION_DEFINITIONS		'D'
#define FILEACTION_ERROR			'E'
#define FILEACTION_INACTIVE			'X'
#define FILEACTION_STOP				'S'


* Reference types as used by *_ref.reftype
#define REFTYPE_INIT			'I'
#define REFTYPE_SEARCH			'S'
#define REFTYPE_RESULT			'R'
#define REFTYPE_NOMATCH			'N'
#define REFTYPE_ERROR			'E'
#define REFTYPE_LOG				'L'
#define REFTYPE_INACTIVE		'X'

* Where we found the results - used by *_ref.findtype
#define FINDTYPE_CODE			'C'
#define FINDTYPE_TEXT			'T'
#define FINDTYPE_NAME			'N'
#define FINDTYPE_EXPR			'E'
#define FINDTYPE_PROPERTYNAME	'P'
#define FINDTYPE_PROPERTYVALUE	'='
#define FINDTYPE_WINDOW			'W'
#define FINDTYPE_OTHER			'X'

* Definition Types used in RefDef.dbf
#define DEFTYPE_NONE			' '
#define DEFTYPE_PARAMETER		'P'
#define DEFTYPE_LOCAL			'L'
#define DEFTYPE_PRIVATE			'V'
#define DEFTYPE_PUBLIC			'G'
#define DEFTYPE_PROCEDURE		'F'
#define DEFTYPE_CLASS			'C'
#define DEFTYPE_DEFINE			'#'
#define DEFTYPE_PROPERTY		'='
#define DEFTYPE_INCLUDEFILE		'I'
#define DEFTYPE_SETCLASSPROC	'S'


#define LOG_PREFIX	"*** "

* -- The following are used in evaluating report files (frx)

* Report FRX objtypes
#define RPTTYPE_HEADER		1
#define RPTTYPE_DBF			2
#define RPTTYPE_INDEX		3
#define RPTTYPE_RELATION	4
#define RPTTYPE_LABEL		5
#define RPTTYPE_LINE		6
#define RPTTYPE_BOX			7
#define RPTTYPE_GET			8
#define RPTTYPE_BAND		9
#define RPTTYPE_GROUP		10
#define RPTTYPE_PICTURE		17
#define RPTTYPE_VAR			18
#define RPTTYPE_FONT		23
#define RPTTYPE_DATAENV		25
#define RPTTYPE_DERECORD	26


* Report FRX band objcodes (objtype=9)
#define RPTCODE_TITLE		0
#define RPTCODE_PGHEAD		1
#define RPTCODE_COLHEAD		2
#define RPTCODE_GRPHEAD		3
#define RPTCODE_DETAIL		4
#define RPTCODE_GRPFOOT		5
#define RPTCODE_COLFOOT		6
#define RPTCODE_PGFOOT		7
#define RPTCODE_SUMMARY		8

#define MATCH_ANY			'?'
#define MATCH_MORE			'*'

#define EXPORTTYPE_DBF			"DBF"
#define EXPORTTYPE_TXT			"TXT"
#define EXPORTTYPE_HTML			"HTML"
#define EXPORTTYPE_XML			"XML"
#define EXPORTTYPE_XLS			"XLS"
#define EXPORTTYPE_CLIPBOARD	"CLIPBOARD"

* default extension for backups
#define BACKUP_EXTENSION	"bak"

* used by the ShellTo method
#define SW_HIDE             0
#define SW_SHOWNORMAL       1
#define SW_NORMAL           1
#define SW_SHOWMINIMIZED    2
#define SW_SHOWMAXIMIZED    3
#define SW_MAXIMIZE         3
#define SW_SHOWNOACTIVATE   4
#define SW_SHOW             5
#define SW_MINIMIZE         6
#define SW_SHOWMINNOACTIVE  7
#define SW_SHOWNA           8
#define SW_RESTORE          9
#define SW_SHOWDEFAULT      10
#define SW_FORCEMINIMIZE    11
#define SW_MAX              11
#define SE_ERR_NOASSOC 		31

#define HELPTOPIC_GENERAL	"Code References Window"
#define HELPTOPIC_REGEXPR	"Regular Expressions and Operators"


* -- BEGIN LOCALIZATION STRINGS ---

* Name of this application -- used in the caption of MessageBox() functions
#define APPNAME_LOC				"R�f�rences de code"


* Used by Progress form
#define PROGRESS_SEARCHING_LOC	 "Recherche en cours"
#define PROGRESS_REFRESHING_LOC	 "Rafra�chissement"
#define PROGRESS_DEFINITIONS_LOC "Collecte des d�finitions - "

#define SEARCH_CANCEL_LOC		"Etes vous sur de vouloir stopper la recherche ?"
#define CANCEL_LOC				"Annuler"
#define ERROR_LOC				"Erreur"

* these are used in the Left Hand Pane of the results window (don't localize #SYMBOL#)
#define ALLRESULTS_LOC			"Tous les r�sultats"
#define REPLACELOG_LOC			"Remplacement de l'occurence: #SYMBOL#"
#define ALLLOGS_LOC				"Remplacement des occurences"
#define EMPTYTEXT_LOC			"(Rien)"

#define SCOPE_PROJECT_LOC		"Projet"
#define SCOPE_FOLDER_LOC		"Dossier"
#define SCOPE_FILE_LOC			"Fichier courant"
#define SCOPE_CLASS_LOC			"Classe courante"

* Search Comments and non comments (0), Exclude Comments (1), or Comments Only (2)
#define COMMENTS_INCLUDE	0
#define COMMENTS_EXCLUDE	1
#define COMMENTS_ONLY		2		

* used on the toolbar buttons
#define TOOLBAR_FIND_LOC		"Rechercher"
#define	TOOLBAR_REFRESH_LOC		"Rafra�chir"
#define TOOLBAR_OPTIONS_LOC		"Options"
#define TOOLBAR_REPLACE_LOC		"Remplacer"


#define SLOW_WARNING_LOC		"La cha�ne de recherche sp�cifi�e pourrait prendre beaucoup de temps et" + CHR(10) + "utiliser un large espace disque."
#define WILDCARD_WARNING_LOC	"Vous ne pouvez pas constituer une cha�ne de recherche constitu�e uniquement de joker."
#define CONTINUE_LOC			"Voulez vous continuer?"

* Results Window caption
#define RESULTSTITLE_LOC		"R�f�rences de codes"
#define FOLDERNOEXIST_LOC		"Le dossier sp�cifi� n'existe pas."

#define NAME_LOC				"Name"
#define EXPRESSION_LOC			"Expression"
#define COMMENT_LOC				"Commentaire"
#define PEMNAME_LOC				"Propri�t�/M�thode "

* Descriptions of what we might find in a report
#define OBJECTTYPE_HEADER_LOC	"Ent�te"
#define OBJECTTYPE_DBF_LOC		"DBF"
#define OBJECTTYPE_INDEX_LOC	"Index"
#define OBJECTTYPE_RELATION_LOC	"Relation"
#define OBJECTTYPE_LABEL_LOC	"Etiquette"
#define OBJECTTYPE_LINE_LOC		"Ligne"
#define OBJECTTYPE_BOX_LOC		"Cadre"
#define OBJECTTYPE_GET_LOC		"Obtenir"
#define OBJECTTYPE_TITLE_LOC	"Titre"
#define OBJECTTYPE_PGHEAD_LOC	"Ent�te de page"
#define OBJECTTYPE_COLHEAD_LOC	"Ent�te de colonne"
#define OBJECTTYPE_GRPHEAD_LOC	"Ent�te de groupe"
#define OBJECTTYPE_DETAIL_LOC	"Bande de d�tail"
#define OBJECTTYPE_GRPFOOT_LOC	"Pied de groupe"
#define OBJECTTYPE_COLFOOT_LOC	"Pied de colonne"
#define OBJECTTYPE_PGFOOT_LOC	"Pied de page"
#define OBJECTTYPE_SUMMARY_LOC	"R�sum�"
#define OBJECTTYPE_BAND_LOC		"Bande"
#define OBJECTTYPE_GROUP_LOC	"Groupe"
#define OBJECTTYPE_PICTURE_LOC	"Image"
#define OBJECTTYPE_VAR_LOC		"Variable"
#define OBJECTTYPE_FONT_LOC		"Police"
#define OBJECTTYPE_DATAENV_LOC	"Environnement de donn�es"
#define OBJECTTYPE_DERECORD_LOC	"Enregistrement d'environnement de donn�es"
#define OBJECTTYPE_UNKNOWN_LOC	"Inconnu"

#define FRX_ONENTRYEXPR_LOC		"En entrant dans l'expression"
#define FRX_ONEXITEXPR_LOC		"En sortant de l'expression"
#define FRX_PRINTONLYWHEN_LOC	"Imprimer seulement quand l'expression"
#define FRX_VARSTORE_LOC		"Valeur � stocker"
#define FRX_VARINITIAL_LOC		"Valeur initiale"

* Descriptions of what we might find in a table (dbf)
#define DBF_FIELDNAME_LOC			"Nom du champ"
#define DBF_FIELDVALIDATIONEXPR_LOC	"Expression de validation du champs"
#define DBF_FIELDVALIDATIONTEXT_LOC	"Texte du champs de validation"
#define DBF_DEFAULTVALUE_LOC		"Valeur par d�faut"
#define DBF_TABLEVALIDATIONEXPR_LOC	"R�gle de validation du champs"
#define DBF_TABLEVALIDATIONTEXT_LOC	"Texte de la r�gle de validation"
#define DBF_TABLELONGNAME_LOC		"Nom long de la table"
#define DBF_INSERTTRIGGER_LOC		"Expression du trigger insertion"
#define DBF_UPDATETRIGGER_LOC		"ExpresSion du trigger mise � jour"
#define DBF_DELETETRIGGER_LOC		"Expression du trigger supression"
#define DBF_TAGNAME_LOC				"Nom du tag d'index"
#define DBF_TAGEXPR_LOC				"Expression du tag d'index"
#define DBF_TAGFILTER_LOC			"Filtre du tag d'index"


* Descriptions of what we might find in a database (dbc)
#define DBC_STOREDPROCEDURE_LOC		"Procedure sotck�e"
#define DBC_COMMENT_LOC				"Commentaire sur la Base de Donn�e"

#define DBC_VIEWNAME_LOC			"Nom de la vue"
#define DBC_VIEWSQL_LOC				"Source SQL de la vue"
#define DBC_VIEWCOMMENT_LOC			"Commentaire sur la vue"
#define DBC_VIEWPARAMETERS_LOC		"Parametres de la vue"
#define DBC_VIEWCONNECTNAME_LOC		"Nom de la connection"
#define DBC_VIEWRULEEXPR_LOC		"Expression de la r�gle de la vue"
#define DBC_VIEWRULETEXT_LOC		"Texte de la r�gle de la vue"

#define DBC_CONNECTNAME_LOC			"Nom de la connection"
#define DBC_CONNECTSTRING_LOC		"Cha�ne de connection"
#define DBC_CONNECTCOMMENT_LOC		"Connection - Commentaire"
#define DBC_CONNECTDATABASE_LOC		"connection - Base de donn�e"
#define DBC_CONNECTDATASOURCE_LOC	"Connection - Source de donn�e"
#define DBC_CONNECTUSERID_LOC		"Connection - Identifiant"
#define DBC_CONNECTPASSWORD_LOC		"Connection - Mot de passe"


* Descriptions of what we might find in a menu (mnx)
#define MNX_NAME_LOC				"Nom"
#define MNX_PROMPT_LOC				"Prompt"
#define MNX_COMMAND_LOC				"Commande"
#define MNX_MESSAGE_LOC				"Message"
#define MNX_PROCEDURE_LOC			"Proc�dure"
#define MNX_SETUP_LOC				"Initialisation"
#define MNX_CLEANUP_LOC				"Nettoyage"
#define MNX_SKIPFOR_LOC				"Sauter lors"
#define MNX_RESOURCE_LOC			"Ressource"
#define MNX_COMMENT_LOC				"Commentaire"

* Grid headers on the results form
#define GRID_FILENAME_LOC			"Nom de fichier"
#define GRID_CLASSMETHOD_LOC		"Classe.Methode, Ligne"
#define GRID_CODE_LOC				"Code"

#define REPLACE_LOC					"Remplacer"
#define REPLACE_NOCHECKS_LOC  		"S�l�ctionnez d'abord les �l�ments sur lesquels vous voulez �ffectuer les remplacements."
#define REPLACE_REFRESH_LOC			"Voulez vous rafra�chir le r�sultat?"
#define REPLACE_NOTSUPPORTED1_LOC	"Certains �l�ments s�lectionn�s ne sont pas support�s par R�f�rences de code" + CHR(10) + "(Structure des donn�es, nom & valeur de propri�t�s)."
#define REPLACE_NOTSUPPORTED2_LOC	"Le rapport d'activit� qui suit l'op�ration de remplacement" + CHR(10) + "contient les instructions n�cessaire pour �ffectuer ces changements."
#define REPLACE_SKIPPED				"Ignor�"
#define REPLACE_NOTSUPPORTED_LOC	"Remplacement non support�"
#define REPLACE_READONLY_LOC		"Le fichier est en lecture seule."

* when user selects "Go To Definition" and no definition exists, display this message
#define NODEFINITION_LOC			"D�finition non trouv� pour ce qui suit :"
#define GOTODEFINITION_LOC			"Allez � la d�finition"


* Descriptions of the Export Types
#define EXPORT_DBF_LOC				"Table Visual FoxPro (DBF)"
#define EXPORT_TXT_LOC				"Texte d�limit� par des virgules (TXT)"
#define EXPORT_HTML_LOC				"HyperText Markup Language (HTML)"
#define EXPORT_XML_LOC				"Extensible Markup Language (XML)"
#define EXPORT_XLS_LOC				"Microsoft Excel"
#define EXPORT_CLIPBOARD_LOC		"Presse Papier"

* valid values for XMLExportType
#define	XMLFORMAT_ELEMENTS			1
#define	XMLFORMAT_ATTRIBUTES		2


* used by FileMatch method in FoxRefEngine
#define FILEMATCH_ANY		'?'
#define FILEMATCH_MORE		'*'


* What to display if there are no matching records
* when printing results report
#define PRINT_NOTHING_LOC			"Aucun r�sultat."

* What we display in the Search Comments combo box on the Find dialog
#define COMMENTS_INCLUDE_LOC		"Inclure les commentaires"
#define COMMENTS_EXCLUDE_LOC		"Ignorer les commentaires"
#define COMMENTS_ONLY_LOC			"Commentaires seulement"

#define CRITERIA_MATCHCASE_LOC		"Conserver la casse"
#define CRITERIA_WHOLEWORDS_LOC		"Mot entier seulement"
#define CRITERIA_FORMPROPERTIES_LOC	"Rechercher nom/valeur de propri�t�s"
#define CRITERIA_PROJECTHOMEDIR_LOC	"Dossier racine du projet seulement"
#define CRITERIA_SUBFOLDERS_LOC		"Inclure les sous dossiers"
#define CRITERIA_WILDCARDS_LOC		"Expression r�guli�re"

* used in FoxRefResults as titles for our criteria and filetypes
#define SEARCHOPTIONS_LOC			"Options"
#define FOLDER_LOC					"Dossier"
#define PROJECT_LOC					"Projet"
#define ERRORHEADER_LOC				"Alertes/Erreurs:"
#define SUMMARY_NOMATCHES_LOC		"Pas de correspondance trouv�e"
#define REPLACEMENTTEXT_LOC			"Texte de remplacement"
#define DATETIME_LOC				"Date/Heure"

* don't localize <MATCHCNT>, <FILECNT>, or <FILENAME> -- they are placeholders!
#define SUMMARY1_LOC				"<MATCHCNT> correspondances trouv�es dans <FILECNT> fichiers"
#define SUMMARY2_LOC				"<MATCHCNT> correspondance trouv�e <FILECNT> fichiers"
#define SUMMARY3_LOC				"<MATCHCNT> correspondances trouv�es dans <FILECNT> fichier"
#define SUMMARY4_LOC				"<MATCHCNT> correspondances trouv�es <FILECNT> fichiers"
#define SUMMARY5_LOC				"<MATCHCNT> correspondance trouv�e <FILENAME>"
#define SUMMARY6_LOC				"<MATCHCNT> coresspondances trouv�es <FILENAME>"

* errors that could occur when creating or opening *_Ref table
#define ERROR_BADREFTABLE_LOC		"La table de r�f�rence est en cours d'utilisation par une autre application :"
#define ERROR_CREATEREFTABLE_LOC	"La table de r�f�rence ne peut �tre cr��e :"
#define ERROR_OPENREFTABLE_LOC		"La table de r�f�rence ne peut �tre ouverte :"

#define ERROR_BADDEFTABLE_LOC		"La table de d�finitions est en cours d'utilisation par une autre application :"
#define ERROR_CREATEDEFTABLE_LOC	"La table de d�finitions ne peut �tre cr��e : "
#define ERROR_OPENDEFTABLE_LOC		"La table de d�finitions ne peut �tre ouverte : "

#define ERROR_BADFILETABLE_LOC		"Le fichier table est en cours d'utilisation par une autre application :"
#define ERROR_CREATEFILETABLE_LOC	"Le fichier table ne peut �tre cr�� :"
#define ERROR_OPENFILETABLE_LOC		"Le fichier table ne peut �tre ouvert :"

#define ERROR_REPLACE_LOC			"Erreur rencontr�e lors du remplacement"
#define ERROR_NOBACKUP_LOC			"Une sauvegarde ne peut �tre effectu�e, de ce fait le remplacement ne sera pas effectu�."
#define ERROR_FILENOTFOUND_LOC		"Fichier non trouv�"
#define ERROR_FILEMODIFIED_LOC		"Mise � jour impossible car le fichier a �t� modifi�"
#define ERROR_WRITE_LOC				"Erreur rencontr�e lors de l'enregistrement du fichier (peut-�tre en lecture seule)"
#define ERROR_NOENGINE_LOC			"Moteur de recherche/remplacement non d�finis pour ce type de fichier"
#define ERROR_PATTERN_LOC			"Le moteur de recherche ne supporte pas l'expression sp�cifi�e."
#define ERROR_SEARCHENGINE_LOC		"Une erreur s'est produite pendant la recherche." + CHR(10) + "L'expression recherch�e est peut �tre invalide."

* errors that can occur
#define ERROR_OPENFILE_LOC			"Impossible d'ouvrir le fichier (Le fichier doit �tre en cours d'utilisation)"
#define ERROR_NOTFORM_LOC			"Le fichier n'est pas un formulaire ou une librairie de classes"
#define ERROR_NOTMENU_LOC			"Le fichier n'est pas un menu"
#define ERROR_NOTREPORT_LOC			"Le fichier n'est pas un �tat ou un �tat d'�tiquettes"
#define ERROR_EXCLUSIVE_LOC			"Impossible d'ouvrir les tables en mode exclusif pour nettoyage."
#define ERROR_FOXTOOLS_LOC			"Impossible de localiser la librairie FOXTOOLS.FLL"

* confirmation when Cleanup button is pressed on Options dialog
#define CLEANUP_CONFIRM_LOC			"Etes vous sur de vouloir enlever toutes les r�f�rences et d�finitions " + CHR(10) + "de fichiers inutilis�es des tables de R�f�rences de code"

* used in FoxRefPrint when error encountered
#define ERROR_PRINT_LOC				"Erreur rencontr�e lors de l'ex�cution de l'�tat."

* when "Clear All Results" is selected, confirm with this prompt
#define CLEARALL_LOC				"Etes vous sur de vouloir effacer tous les ensembles de r�sultats et de remplacments ?"
#define CLEARALL_CAPTION_LOC		"Tout effacer"
#define CLEARALLRESULTS_LOC			"Etes vous sur de vouloir effacer tous les ensembles de r�sultats?"
#define CLEARALLRESULTS_CAPTION_LOC	"Effacer tous les r�sultats"

* used in FoxRefReplaceConfirm.scx to show what we're replacing
#define REPLACECONFIRM_REPLACE_LOC	"Remplacer :"
#define REPLACECONFIRM_WITH_LOC		"Avec :"

#define BACKUP_PREFIX_LOC			"Sauvegarde de"

* right-click menu options from FoxRefResults.scx -> ShowRightClickMenu()
#define MENU_DESCRIPTIONS_LOC		"Afficher \<Descriptions"
#define MENU_ALWAYSONTOP_LOC		"Toujours \<Au dessus"
#define MENU_OPENPROJECT_LOC		"\<Ouvrir Projet"
#define MENU_SEARCH_LOC				"\<Chercher"
#define MENU_GLOBALREPLACE_LOC		"\<Remplacer"
#define MENU_REFRESH_LOC			"Ra\<fra�chir"
#define MENU_PRINT_LOC				"Im\<primer"
#define MENU_EXPORT_LOC				"\<Exporter"
#define MENU_OPTIONS_LOC			"Opt\<ions"

#define MENU_COPY_LOC				"\<Copier"
#define MENU_CLEAR_LOC				"Efface\<r R�sultat"
#define MENU_CLEARALL_LOC			"Eff\<acer Tous Les r�sulats"

#define MENU_OPEN_LOC				"\<Ouvrir"
#define MENU_GOTODEFINITION_LOC			"\<Voir D�finition"
#define MENU_SELECTALL_LOC			"\<S�lectionner Tout"
#define MENU_DESELECTALLWIN_LOC			"\<Effacer Toutes Les S�lections Affich�e"
#define MENU_DESELECTALL_LOC			"E\<ffacer Toutes Les S�lections"
#define MENU_SORT_LOC				"\<Trier par"

#define MENUSORT_FILENAME_LOC		"\<Nom de fichier"
#define MENUSORT_CHECKED_LOC		"\<Selectionner"
#define MENUSORT_CLASSMETHOD_LOC	"\<Classe.Methode"
#define MENUSORT_METHOD_LOC			"\<Methode"
#define MENUSORT_FILETYPE_LOC		"\<Type de fichier"
#define MENUSORT_LOCATION_LOC		"Emp\<lacement"

#define MENU_EXPANDALL_LOC			"Developp\<er Tout"
#define MENU_COLLAPSEALL_LOC		"R�duire T\<out"
#define MENU_SORTMOSTRECENT_LOC		"Plus R�cent D'Abord"

* used in place of Filename during Goto Definition when
* the definitions actually came from the open window
#define OPENWINDOW_LOC				"Ouvrir Fen�tre"

#define FILEEXISTS_LOC				"#FILENAME# existe d�j�." + CHR(10) + "Voulez vous le remplacer?"
#define FILE_INVALID_LOC			"Nom de fichier invalide."
#define SAVEAS_LOC					"Enregistrer sous"

#define FILETYPE_ALL_LOC			"Tous les fichiers (*.*)"
#define FILETYPE_COMMON_LOC			"Commun (*.scx;*.vcx;*.prg;*.frx;*.lbx;*.mnx;*.dbc;*.qpr;*.h)"
#define FILETYPE_SOURCE_LOC			"Sources (*.scx;*.vcx;*.prg;*.frx;*.lbx;*.mnx;*.dbc;*.dbf;*.cdx;*.qpr;*.h)"
#define FILETYPE_FORMSCLASSES_LOC	"Formulaires et Classes (*.scx;*.vcx;*.prg)"
#define FILETYPE_REPORTS_LOC		"Etats et Etiquettes (*.frx;*.lbx)"
#define FILETYPE_MENUS_LOC			"Menus (*.mnx)"
#define FILETYPE_PROGRAMS_LOC		"Programmes (*.prg;*.h;*.qpr;*.mpr)"
#define FILETYPE_DATA_LOC			"Donn�es (*.dbc;*.dbf;*.cdx)"
#define FILETYPE_TEXT_LOC			"Textes (*.txt;*.xml;*.xsl;*.htm;*.html;*.log;*.asp;*.aspx)"

* used in the Regular Expression help menu on the Search dialog
#define REGEXPR_SINGLECHAR_LOC		". Un caract�re unique parmi tous"
#define REGEXPR_ZEROORMORE_LOC		"* Z�ro or plus"
#define REGEXPR_ONEORMORE_LOC		"+ Un ou plus"
#define REGEXPR_BEGINNINGOFLINE_LOC	"^ D�but de la ligne"
#define REGEXPR_ENDOFLINE_LOC		"$ Fin de la ligne"
#define REGEXPR_ANYONECHAR_LOC		"[] Un des caract�res de l'ensemble"
#define REGEXPR_NOTANYONECHAR_LOC	"[^] Aucun des caract�res de l'ensemble"
#define REGEXPR_OR_LOC				"| OU"
#define REGEXPR_ESCAPE_LOC			"\\ S�quence d'�chappement pour un caract�re sp�cial"
#define REGEXPR_HELP_LOC			"Aide sur les expressions r�guli�res"

* Used in FoxRefOptions dialog
#define FOXREFDIRECTORY_NOEXIST_LOC	"Le dossier sp�cifi� pour les tables de r�f�rences de codes n'existe pas." + CHR(10) + CHR(10) + "Etes vous sur que cela soit correct?"

#define WSH_REQUIRED_LOC			"Windows Script Host doit �tre install� pour la recherche d'expressions r�guli�res."

#define NODE_LOADING_LOC			"(Chargement...)"

#define CLASS_HEADER_LOC			"Classe"