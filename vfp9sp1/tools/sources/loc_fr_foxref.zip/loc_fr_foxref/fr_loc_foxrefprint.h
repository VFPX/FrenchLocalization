* FR_LOC_FOXREFPRINT.H 
* francisation compl�mentaire du foxrefprint.scx
*
* pr�fixe B pour buttons
* pr�fixe L pour les labels
* pr�fixe K pour les chekbox
*
* xxx0_LOC pour le caption
* xxx1_LOC pour le statusbartext
* xxx2_LOC pour le tooltiptext

#DEFINE FR_REFPRINT0		"Imprimer"

#DEFINE B_FR_PRINT0			"\<Imprimer"
#DEFINE B_FR_PREVIEW0		"\<Aper�u"

#DEFINE L_FR_PRINTLABEL10	"Etendue"
#DEFINE L_FR_PRINTLABEL20	"\<Rapport"
#DEFINE L_FR_SET0			"Rec\<hercher dans:"

#DEFINE O_FR_PRINT_OPT10	"\<Tous"
#DEFINE O_FR_PRINT_OPT20	"\<Items s�lectionn�s seulement"

