* FR_LOC_FOXREFREPLACE.H 
* francisation compl�mentaire du foxrefreplace.scx
*
* pr�fixe B pour buttons
* pr�fixe L pour les labels
* pr�fixe K pour les chekbox
*
* xxx0_LOC pour le caption
* xxx1_LOC pour le statusbartext
* xxx2_LOC pour le tooltiptext

#DEFINE FR_REPLACE0_LOC		"Remplace"

#DEFINE B_FR_CLOSE0_LOC		"Fermer"
#DEFINE B_FR_REPLACE0_LOC	"Remplacer"

#DEFINE L_FR_REPLACE0_LOC	"Rem\<placer par:"
#DEFINE L_FR_REPERROR0_LOC	"Erreurs sur le Remplacement:"

#DEFINE K_FR_BACKUP0_LOC		"\<Sauvegarder les fichiers modifi�s"
#DEFINE K_FR_CONFIRM0_LOC	"\<Confirmer les remplacements"
