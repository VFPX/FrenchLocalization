* SUPERCLS.H - Header file for Supercls files.
*

*-- Messages
#DEFINE	M_CODE_NOTFOUND_LOC			"Le code est introuvable"
#DEFINE M_CODE_WIN_NOT_ACTIVE_LOC	"La fen�tre d'�dition de code pour une m�thode n'est pas active"
#DEFINE M_EDIT_LOC					"Editer"
#DEFINE M_EMPTY_IN_HIERARCHY_LOC	"est vide dans la hi�rarchie de la classe"
#DEFINE	M_INSTANCE_BASECLASS_LOC	"Cet objet est une instance de la classe de base"
#DEFINE	M_INSTANCE_NOTFOUND_LOC		"Cet objet est une instance d'une classe VCX introuvable"
#DEFINE	M_INSTANCE_NOTOPENED_LOC	"Cet objet est une instance d'une classe VCX qui ne peut �tre ouverte"
#DEFINE M_METHOD_LOC				"M�thode"
#DEFINE	M_OBJECT_NOT_FOUND_LOC		"L'objet en cours d'�dition est introuvable"
#DEFINE	M_SPRCLSCODE_NOTFOUND_LOC	"Le code Superclass est introuvable"
#DEFINE M_SAVE_CHANGES_TO_LOC		"Sauver les modifications dans"
#DEFINE M_SELECT_OBJECT_EDIT_LOC	"S�lectionnez cet objet avant d'�diter la portion de code"
#DEFINE M_WHERE_IS_LOC				"O� est"

*-- ASCII codes
#DEFINE	EOB		CHR(0)
#DEFINE MARKER	CHR(1)
#DEFINE TAB		CHR(9)
#DEFINE LF		CHR(10)
#DEFINE CR		CHR(13)
#DEFINE CR_LF	CR+LF
