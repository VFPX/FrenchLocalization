* FR_LOC_BROWSER.H 
* francisation compl�mentaire du browser.scx
*
* xxx0_LOC pour le caption (pas utilis� dans ce h)
* xxx1_LOC pour le statusbartext
* xxx2_LOC pour le tooltiptext

#DEFINE B_FR_OPTIONS_LOC "Modifie diff�rents param�tres des options du Component Gallery"
#DEFINE B_FR_EXPORT1_LOC "Affiche le code de (des) d�finition(s) de classe"
#DEFINE B_FR_EXPORT2_LOC "Voir le code  de la Classe"
#DEFINE B_FR_SUBCLASS1_LOC "Cr�e une nouvelle d�finiton de classe"
#DEFINE B_FR_SUBCLASS2_LOC "Nouvelle Classe"
#DEFINE B_FR_FIND1_LOC "Cherche un texte particulier"
#DEFINE B_FR_FIND2_LOC "Cherche"
#DEFINE B_FR_RENAME1_LOC "Change le nom de la classe s�lectionn�e"
#DEFINE B_FR_RENAME2_LOC "Renomme"
#DEFINE B_FR_REDEFINE1_LOC "Modifie la classe parent de la classe s�lectionn�e"
#DEFINE B_FR_REDEFINE2_LOC "Red�finit"
#DEFINE B_FR_CLEANUP1_LOC "Ex�cute la commande PACK pour supprimer d�finitement les enregistrements marqu�s � delete dans le .VCX"
#DEFINE B_FR_CLEANUP2_LOC "Compacte le fichier de classe"
#DEFINE B_FR_UPONELEVEL1_LOC "Va au dossier parent"
#DEFINE B_FR_UPONELEVEL2_LOC "Parent"
#DEFINE B_FR_GOBACK1_LOC "Revient en arri�re d'une �tape"
#DEFINE B_FR_GOBACK2_LOC "En Arri�re"
#DEFINE B_FR_GOFORWARD1_LOC "Se d�place en avant d'une �tape"
#DEFINE B_FR_GOFORWARD2_LOC "En Avant"
#DEFINE B_FR_STOP1_LOC "Arr�t de l'ouverture du fichier"
#DEFINE B_FR_REFRESH1_LOC "Actualise le contenu de la page en cours"
#DEFINE B_FR_REFRESH2_LOC "Actualise"
#DEFINE B_FR_ADD1_LOC "Ajoute un fichier � examiner"
#DEFINE B_FR_ADD2_LOC "Voir un fichier de plus"
