
#define MESSAGE_LOC			"Microsoft Visual FoxPro"
#define ERRORTITLE_LOC		"Microsoft Visual FoxPro"
#define ERRORMESSAGE_LOC ;
	"Erreur #" + alltrim(str(m.nError)) + " dans " + m.cMethod + ;
	" (" + alltrim(str(m.nLine)) + "): " + m.cMessage

#define MB_ICONEXCLAMATION		48
#define MB_ABORTRETRYIGNORE		2
#define MB_OK					0
#DEFINE MB_YESNO                4       && Boutons Oui et Non
#DEFINE IDYES           		6       && Bouton Oui s�lectionn�

* Liste des pays/r�gions pour activer le DBCS : Japon, Cor�e, Chine, Taiwan
#DEFINE DBCS_LOC "81 82 86 88"

#DEFINE NUM_AFIELDS  18   			&& Nombre de colonnes dans le tableau AFIELDS
#DEFINE DT_MEMO  	"M"
#DEFINE DT_GENERAL  "G"

#DEFINE TAGDELIM	 " *"

#DEFINE BMP_LOCAL		"dblview.bmp"
#DEFINE BMP_REMOTE		"dbrview.bmp"
#DEFINE BMP_TABLE		"dbtable.bmp"

#DEFINE C_FREETABLE_LOC		"Tables autonomes"
#DEFINE C_MAXFIELDS_LOC 	"Le nombre maximum de champs � trier est "
#DEFINE C_NOTAG_LOC 		"Vous ne pouvez pas combiner les rep�res d'index et les champs."
#DEFINE C_READONLY_LOC		"Le fichier est en lecture seule et n'est pas autoris� par cette application. Choisissez en un autre."
#DEFINE E_BADDBCTABLE_LOC	"La table s�lectionn�e n'a pas de lien descendant valide vers son DBC. "+;
				"Il est possible d'y rem�dier avec la commande VALIDATE DATABASE RECOVER."
#DEFINE C_TPROMPT_LOC		"S�lectionnez le fichier � ouvrir:"
#DEFINE C_READ2_LOC		"Le fichier est ouvert en exclusive par quelqu'un d'autre."
#DEFINE C_READ3_LOC		"Le fichier est d�j� ouvert. S�lectionnez en un autre."
#DEFINE C_READ4_LOC		"Le DBF fait partie d'un DBC. S�lectionnez la table � partir du conteneur DBC."
